-- Property Listing Database Schema
CREATE DATABASE IF NOT EXISTS property_listing CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE property_listing;

CREATE TABLE IF NOT EXISTS agents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    role VARCHAR(100) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    phone VARCHAR(40) NOT NULL
);

INSERT INTO agents (name, role, email, phone) VALUES
('Noncedo Vilakati', 'Estate Agent', 'nooncedo@gmail.com', '+268790123045'),
('Sibusiso Mhlanga', 'Estate Agent', 'Sibi@gmail.com', '+2687894321')
ON DUPLICATE KEY UPDATE
    name = VALUES(name),
    role = VALUES(role),
    phone = VALUES(phone);

CREATE TABLE IF NOT EXISTS properties (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    property_type ENUM('House','Apartment','Land','Commercial','Townhouse') NOT NULL DEFAULT 'House',
    listing_type ENUM('Sale','Rent') NOT NULL DEFAULT 'Sale',
    price DECIMAL(12,2) NOT NULL,
    location VARCHAR(150) NOT NULL,
    bedrooms INT DEFAULT 0,
    bathrooms INT DEFAULT 0,
    size_sqm DECIMAL(10,2) DEFAULT 0,
    image VARCHAR(255) DEFAULT NULL,
    featured TINYINT(1) DEFAULT 0,
    status ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
    agent_id INT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_properties_public (status, listing_type, featured, created_at),
    INDEX idx_properties_type_price (status, property_type, price),
    INDEX idx_properties_agent (agent_id),
    CONSTRAINT fk_properties_agent FOREIGN KEY (agent_id) REFERENCES agents(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('user','admin','agent') NOT NULL DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE users MODIFY role ENUM('user','admin','agent') NOT NULL DEFAULT 'user';

CREATE TABLE IF NOT EXISTS agent_deals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    agent_id INT NOT NULL,
    property_title VARCHAR(150) NOT NULL,
    deal_type ENUM('Sale','Rent') NOT NULL,
    deal_amount DECIMAL(12,2) NOT NULL,
    commission_rate DECIMAL(5,2) NOT NULL,
    commission_amount DECIMAL(12,2) NOT NULL,
    closed_on DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_agent_deals_agent FOREIGN KEY (agent_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS leads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    property_id INT DEFAULT NULL,
    property_title VARCHAR(150) NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(190) NOT NULL,
    phone VARCHAR(40) DEFAULT NULL,
    message TEXT NOT NULL,
    status ENUM('New','Contacted','Qualified','Closed') NOT NULL DEFAULT 'New',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Sample properties
INSERT INTO properties (title, description, property_type, listing_type, price, location, bedrooms, bathrooms, size_sqm, image, featured, status) VALUES
('Modern Family Home', 'A beautiful modern 4-bedroom family home with a spacious garden and double garage.', 'House', 'Sale', 1850000.00, 'Mbabane', 4, 3, 320, 'modern-family-home.jpg', 1, 'Approved'),
('Cozy 2-Bed Apartment', 'Comfortable apartment close to town, ideal for young professionals.', 'Apartment', 'Rent', 6500.00, 'Manzini', 2, 1, 85, 'cozy-apartment.jpg', 0, 'Approved'),
('Prime Commercial Plot', 'Well-located commercial stand suitable for retail or office development.', 'Land', 'Sale', 950000.00, 'Ezulwini', 0, 0, 1200, 'commercial-plot.jpg', 1, 'Approved'),
('Luxury Townhouse', 'Secure townhouse complex with pool and 24-hour security.', 'Townhouse', 'Sale', 2200000.00, 'Mbabane', 3, 2, 210, 'luxury-townhouse.jpg', 0, 'Approved');

UPDATE properties p
JOIN agents a ON a.email = 'nooncedo@gmail.com'
SET p.agent_id = a.id
WHERE p.agent_id IS NULL;

UPDATE properties p
JOIN agents a ON a.email = 'Sibi@gmail.com'
SET p.agent_id = a.id
WHERE p.title = 'Prime Commercial Plot';
