<?php require_once __DIR__ . '/../include/config.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$canViewUnapproved = is_logged_in() ? 1 : 0;
$stmt = $conn->prepare("SELECT p.*, a.name AS agent_name, a.role AS agent_role, a.email AS agent_email, a.phone AS agent_phone
    FROM properties p
    LEFT JOIN agents a ON a.id = p.agent_id
    WHERE p.id = ? AND (p.status = 'Approved' OR ? = 1)");
$stmt->bind_param('ii', $id, $canViewUnapproved);
$stmt->execute();
$property = $stmt->get_result()->fetch_assoc();

if (!$property) {
    header('Location: ../index.php');
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($property['title']) ?> | EswatiniHomes</title>
<link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
<style>
    :root{--primary:#0f5132;--primary-dark:#0a3622;--accent:#d4a017;--bg:#f6f7f5;--muted:#6b7280;--radius:10px;}
    *{box-sizing:border-box;margin:0;padding:0;}
    body{font-family:'Segoe UI',Arial,sans-serif;background:var(--bg);color:#222;}
    header{background:linear-gradient(135deg,var(--primary),var(--primary-dark));color:#fff;padding:18px 30px;display:flex;justify-content:space-between;align-items:center;}
    header .logo{font-size:22px;font-weight:700;}
    header .logo span{color:var(--accent);}
    nav a{color:#fff;text-decoration:none;margin-left:20px;font-size:15px;}
    nav a:hover{color:var(--accent);}
    .container{max-width:950px;margin:30px auto;padding:0 20px 60px;}
    .back-link{display:inline-block;margin-bottom:16px;color:var(--primary);text-decoration:none;font-size:14px;}
    .photo{width:100%;height:400px;object-fit:cover;border-radius:var(--radius);background:linear-gradient(135deg,#cfd9c7,#e5e9df);display:flex;align-items:center;justify-content:center;color:#8a9584;}
    .info-box{background:#fff;border-radius:var(--radius);padding:26px;margin-top:20px;box-shadow:0 3px 12px rgba(0,0,0,.08);}
    .badge{display:inline-block;font-size:12px;padding:4px 10px;border-radius:20px;background:var(--primary);color:#fff;margin-bottom:10px;}
    .badge.rent{background:var(--accent);}
    h1{font-size:26px;margin-bottom:6px;}
    .location{color:var(--muted);margin-bottom:14px;}
    .icon-text{display:inline-flex;align-items:center;gap:5px;}
    .icon-text i{font-size:18px;line-height:1;}
    .price{font-size:24px;font-weight:700;color:var(--primary-dark);margin-bottom:18px;}
    .meta-grid{display:flex;gap:26px;flex-wrap:wrap;margin-bottom:20px;padding:16px 0;border-top:1px solid #eee;border-bottom:1px solid #eee;}
    .meta-grid div{text-align:center;}
    .meta-grid strong{display:block;font-size:18px;color:var(--primary-dark);}
    .meta-grid span{font-size:13px;color:var(--muted);}
    .description{line-height:1.7;color:#333;margin-bottom:20px;}
    .agent-card{border-top:1px solid #e5e7eb;margin-top:24px;padding-top:20px;}
    .agent-card h2{font-size:20px;color:var(--primary-dark);margin-bottom:14px;}
    .agent-name{font-size:18px;font-weight:700;color:#222;}
    .agent-role{color:var(--muted);margin:4px 0 14px;}
    .agent-contact{display:flex;gap:12px;flex-wrap:wrap;}
    .agent-contact a{display:inline-flex;align-items:center;gap:6px;background:var(--primary);color:#fff;padding:10px 16px;border-radius:6px;text-decoration:none;font-weight:600;}
    .agent-contact a:hover{background:var(--primary-dark);}
    footer{background:var(--primary-dark);color:#eee;text-align:center;padding:20px;font-size:13px;margin-top:40px;}
</style>
</head>
<body>
<header>
    <div class="logo">Eswatini<span>Homes</span></div>
    <nav>
        <a href="../index.php">Home</a>
        <a href="add.php">List a Property</a>
        <?php if (is_logged_in()): ?>
            <a href="../admin/dashboard.php">Admin Dashboard</a>
            <span>Admin: <?= htmlspecialchars($_SESSION['username']) ?></span>
            <a href="../auth/logout.php">Logout</a>
        <?php elseif (is_user_logged_in()): ?>
            <span><?= htmlspecialchars($_SESSION['username']) ?></span>
            <a href="../auth/logout.php">Logout</a>
        <?php else: ?>
            <a href="../auth/login.php">Sign In</a>
            <a href="../auth/register.php">Register</a>
        <?php endif; ?>
    </nav>
</header>

<div class="container">
    <a class="back-link" href="../index.php"><i class="bx bx-chevron-left" aria-hidden="true"></i> Back to listings</a>

    <?php if (property_image_exists($property['image'])): ?>
        <img class="photo" src="<?= htmlspecialchars(property_image_url($property['image'])) ?>" alt="<?= htmlspecialchars($property['title']) ?>">
    <?php else: ?>
        <div class="photo">No Image Available</div>
    <?php endif; ?>

    <div class="info-box">
        <span class="badge <?= $property['listing_type'] === 'Rent' ? 'rent' : '' ?>">
            <?= htmlspecialchars($property['listing_type'] === 'Rent' ? 'For Rent' : 'For Sale') ?> · <?= htmlspecialchars($property['property_type']) ?>
        </span>
        <h1><?= htmlspecialchars($property['title']) ?></h1>
        <div class="location icon-text"><i class="bx bx-map-pin" aria-hidden="true"></i><?= htmlspecialchars($property['location']) ?></div>
        <div class="price"><?= currency($property['price']) ?><?= $property['listing_type'] === 'Rent' ? ' /mo' : '' ?></div>

        <div class="meta-grid">
            <div><strong><?= (int)$property['bedrooms'] ?></strong><span>Bedrooms</span></div>
            <div><strong><?= (int)$property['bathrooms'] ?></strong><span>Bathrooms</span></div>
            <div><strong><?= (float)$property['size_sqm'] ?></strong><span>m²</span></div>
        </div>

        <p class="description"><?= nl2br(htmlspecialchars($property['description'])) ?></p>

        <?php if ($property['agent_name'] !== null): ?>
        <section class="agent-card" aria-labelledby="agent-heading">
            <h2 id="agent-heading">Contact the Agent</h2>
            <div class="agent-name"><?= htmlspecialchars($property['agent_name']) ?></div>
            <div class="agent-role"><?= htmlspecialchars($property['agent_role']) ?></div>
            <div class="agent-contact">
                <a href="mailto:<?= htmlspecialchars($property['agent_email']) ?>"><i class="bx bx-envelope" aria-hidden="true"></i>Email <?= htmlspecialchars($property['agent_name']) ?></a>
                <a href="tel:<?= htmlspecialchars(preg_replace('/[^0-9+]/', '', $property['agent_phone'])) ?>"><i class="bx bx-phone" aria-hidden="true"></i>Call <?= htmlspecialchars($property['agent_phone']) ?></a>
            </div>
        </section>
        <?php endif; ?>

        <?php if (is_logged_in()): ?>
            <div style="margin-top:16px;">
                <a href="edit.php?id=<?= $property['id'] ?>" style="margin-right:14px;color:var(--primary);">Edit</a>
                <form method="POST" action="delete.php" style="display:inline;" onsubmit="return confirm('Delete this property?');">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">
                    <input type="hidden" name="id" value="<?= (int)$property['id'] ?>">
                    <button type="submit" style="border:0;background:none;color:#b00020;font:inherit;cursor:pointer;">Delete</button>
                </form>
            </div>
        <?php endif; ?>
    </div>
</div>

<footer>&copy; <?= date('Y') ?> EswatiniHomes Property Listings. All rights reserved.</footer>

<script>
    // Confirm before leaving via delete link handled above; extra UX touch:
</script>
</body>
</html>
