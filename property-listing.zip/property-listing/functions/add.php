<?php require_once __DIR__ . '/../include/config.php';

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? null)) {
        $errors[] = 'Your session expired. Refresh the page and try again.';
    } else {
        $title = trim(request_string($_POST, 'title'));
        $description = trim(request_string($_POST, 'description'));
        $property_type = request_string($_POST, 'property_type');
        $listing_type = request_string($_POST, 'listing_type');
        $price = request_string($_POST, 'price');
        $location = trim(request_string($_POST, 'location'));
        $bedrooms = filter_var(request_string($_POST, 'bedrooms', '0'), FILTER_VALIDATE_INT);
        $bathrooms = filter_var(request_string($_POST, 'bathrooms', '0'), FILTER_VALIDATE_INT);
        $size_sqm = request_string($_POST, 'size_sqm', '0');

        if ($title === '' || strlen($title) > 150) $errors[] = 'Enter a property title (up to 150 characters).';
        if ($location === '' || strlen($location) > 150) $errors[] = 'Enter a location (up to 150 characters).';
        if (strlen($description) > 65535) $errors[] = 'Description is too long.';
        if (!in_array($property_type, ['House', 'Apartment', 'Land', 'Commercial', 'Townhouse'], true)) $errors[] = 'Choose a valid property type.';
        if (!in_array($listing_type, ['Sale', 'Rent'], true)) $errors[] = 'Choose a valid listing type.';
        if (!is_numeric($price) || (float)$price <= 0 || (float)$price > 9999999999.99) $errors[] = 'Valid price is required.';
        if ($bedrooms === false || $bedrooms < 0 || $bathrooms === false || $bathrooms < 0) $errors[] = 'Bedrooms and bathrooms must be zero or greater.';
        if (!is_numeric($size_sqm) || (float)$size_sqm < 0 || (float)$size_sqm > 99999999.99) $errors[] = 'Enter a valid property size.';

        $imageName = null;
        if (!$errors) {
            $imageName = save_property_image($_FILES['image'] ?? null, $imageError);
            if ($imageName === false) {
                $errors[] = $imageError;
            }
        }

        if (!$errors) {
            $price = (float)$price;
            $size_sqm = (float)$size_sqm;
            $status = is_logged_in() ? 'Approved' : 'Pending';
            $defaultAgentEmail = 'nooncedo@gmail.com';
            $stmt = $conn->prepare("INSERT INTO properties (title, description, property_type, listing_type, price, location, bedrooms, bathrooms, size_sqm, image, status, agent_id)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,(SELECT id FROM agents WHERE email = ?))");
            $stmt->bind_param('ssssdsiidsss', $title, $description, $property_type, $listing_type, $price, $location, $bedrooms, $bathrooms, $size_sqm, $imageName, $status, $defaultAgentEmail);
            if ($stmt->execute()) {
                $success = true;
            } else {
                delete_property_image($imageName);
                $errors[] = 'The property could not be saved. Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>List a Property | EswatiniHomes</title>
<style>
    :root{--primary:#0f5132;--primary-dark:#0a3622;--accent:#d4a017;--bg:#f6f7f5;--muted:#6b7280;--radius:10px;}
    *{box-sizing:border-box;margin:0;padding:0;}
    body{font-family:'Segoe UI',Arial,sans-serif;background:var(--bg);color:#222;}
    header{background:linear-gradient(135deg,var(--primary),var(--primary-dark));color:#fff;padding:18px 30px;display:flex;justify-content:space-between;align-items:center;}
    header .logo{font-size:22px;font-weight:700;}
    header .logo span{color:var(--accent);}
    nav a{color:#fff;text-decoration:none;margin-left:20px;font-size:15px;}
    .container{max-width:700px;margin:40px auto;padding:0 20px 60px;}
    .form-box{background:#fff;padding:30px;border-radius:var(--radius);box-shadow:0 3px 12px rgba(0,0,0,.08);}
    h1{margin-bottom:20px;color:var(--primary-dark);}
    label{display:block;margin:14px 0 6px;font-weight:600;font-size:14px;}
    input, select, textarea{width:100%;padding:10px 12px;border:1px solid #ddd;border-radius:6px;font-size:14px;font-family:inherit;}
    textarea{resize:vertical;min-height:100px;}
    .row{display:flex;gap:14px;}
    .row > div{flex:1;}
    button{margin-top:22px;background:var(--primary);color:#fff;border:none;padding:12px 26px;border-radius:6px;cursor:pointer;font-weight:600;font-size:15px;}
    button:hover{background:var(--primary-dark);}
    .alert{padding:12px 16px;border-radius:6px;margin-bottom:16px;font-size:14px;}
    .alert.error{background:#fdecea;color:#b00020;}
    .alert.success{background:#e6f4ea;color:#0f5132;}
    footer{background:var(--primary-dark);color:#eee;text-align:center;padding:20px;font-size:13px;margin-top:40px;}
</style>
</head>
<body>
<header>
    <div class="logo">Eswatini<span>Homes</span></div>
    <nav>
        <a href="../index.php">Home</a>
        <a href="add.php">List a Property</a>
        <?php if (is_logged_in()): ?>
            <a href="../admin/dashboard.php">Admin Dashboard</a>
            <span>Admin: <?= htmlspecialchars($_SESSION['username']) ?></span>
            <a href="../auth/logout.php">Logout</a>
        <?php elseif (($_SESSION['role'] ?? '') === 'agent'): ?>
            <a href="../pages/agent-dashboard.php">Agent Dashboard</a>
            <span>Agent: <?= htmlspecialchars($_SESSION['username']) ?></span>
            <a href="../auth/logout.php">Logout</a>
        <?php elseif (is_user_logged_in()): ?>
            <span><?= htmlspecialchars($_SESSION['username']) ?></span>
            <a href="../auth/logout.php">Logout</a>
        <?php else: ?>
            <a href="../auth/login.php">Sign In</a>
            <a href="../auth/register.php">Register</a>
        <?php endif; ?>
    </nav>
</header>

<div class="container">
    <div class="form-box">
        <h1>List a New Property</h1>

        <?php if ($success): ?>
            <div class="alert success"><?= is_logged_in() ? 'Property published successfully!' : 'Property submitted for admin review.' ?> <a href="../index.php">Return to listings</a>.</div>
        <?php endif; ?>

        <?php foreach ($errors as $err): ?>
            <div class="alert error"><?= htmlspecialchars($err) ?></div>
        <?php endforeach; ?>

        <form method="POST" enctype="multipart/form-data" id="propertyForm">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">
            <label>Property Title</label>
            <input type="text" name="title" required value="<?= htmlspecialchars(request_string($_POST, 'title')) ?>">

            <label>Description</label>
            <textarea name="description"><?= htmlspecialchars(request_string($_POST, 'description')) ?></textarea>

            <div class="row">
                <div>
                    <label>Property Type</label>
                    <select name="property_type">
                        <?php foreach (['House','Apartment','Land','Commercial','Townhouse'] as $t): ?>
                            <option value="<?= $t ?>"><?= $t ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label>Listing Type</label>
                    <select name="listing_type">
                        <option value="Sale">For Sale</option>
                        <option value="Rent">For Rent</option>
                    </select>
                </div>
            </div>

            <label>Price (Emalangeni)</label>
            <input type="number" step="0.01" name="price" required value="<?= htmlspecialchars(request_string($_POST, 'price')) ?>">

            <label>Location</label>
            <input type="text" name="location" required value="<?= htmlspecialchars(request_string($_POST, 'location')) ?>">

            <div class="row">
                <div>
                    <label>Bedrooms</label>
                    <input type="number" name="bedrooms" min="0" value="<?= htmlspecialchars(request_string($_POST, 'bedrooms', '0')) ?>">
                </div>
                <div>
                    <label>Bathrooms</label>
                    <input type="number" name="bathrooms" min="0" value="<?= htmlspecialchars(request_string($_POST, 'bathrooms', '0')) ?>">
                </div>
                <div>
                    <label>Size (m²)</label>
                    <input type="number" step="0.01" name="size_sqm" min="0" value="<?= htmlspecialchars(request_string($_POST, 'size_sqm', '0')) ?>">
                </div>
            </div>

            <label>Property Image</label>
            <input type="file" name="image" accept=".jpg,.jpeg,.png,.webp">

            <button type="submit">Submit Property</button>
        </form>
    </div>
</div>

<footer>&copy; <?= date('Y') ?> EswatiniHomes Property Listings. All rights reserved.</footer>

<script>
    // Basic client-side validation feedback
    document.getElementById('propertyForm').addEventListener('submit', function(e){
        const price = parseFloat(this.price.value);
        if (isNaN(price) || price <= 0) {
            alert('Please enter a valid price.');
            e.preventDefault();
        }
    });
</script>
</body>
</html>
