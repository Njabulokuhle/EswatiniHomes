<?php require_once __DIR__ . '/../include/config.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !verify_csrf_token($_POST['csrf_token'] ?? null)) {
    http_response_code(400);
    exit('Invalid request. Return to the dashboard and try again.');
}

$id = (int)($_POST['id'] ?? 0);

$stmt = $conn->prepare("SELECT image FROM properties WHERE id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();

if ($row) {
    $del = $conn->prepare("DELETE FROM properties WHERE id = ?");
    $del->bind_param('i', $id);
    if ($del->execute()) {
        delete_property_image($row['image']);
    }
}

header('Location: ../admin/dashboard.php?updated=property');
exit;
