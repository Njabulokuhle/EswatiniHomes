<?php require_once __DIR__ . '/../include/config.php';
require_login();

$id = isset($_GET['id']) ? (int)$_GET['id'] : (int)($_POST['id'] ?? 0);
$stmt = $conn->prepare("SELECT * FROM properties WHERE id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$property = $stmt->get_result()->fetch_assoc();

if (!$property) {
    header('Location: ../index.php');
    exit;
}

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? null)) {
        $errors[] = 'Your session expired. Refresh the page and try again.';
    } else {
        $title = trim(request_string($_POST, 'title'));
        $description = trim(request_string($_POST, 'description'));
        $property_type = request_string($_POST, 'property_type');
        $listing_type = request_string($_POST, 'listing_type');
        $price = request_string($_POST, 'price');
        $location = trim(request_string($_POST, 'location'));
        $bedrooms = filter_var(request_string($_POST, 'bedrooms', '0'), FILTER_VALIDATE_INT);
        $bathrooms = filter_var(request_string($_POST, 'bathrooms', '0'), FILTER_VALIDATE_INT);
        $size_sqm = request_string($_POST, 'size_sqm', '0');

        if ($title === '' || strlen($title) > 150) $errors[] = 'Enter a property title (up to 150 characters).';
        if ($location === '' || strlen($location) > 150) $errors[] = 'Enter a location (up to 150 characters).';
        if (strlen($description) > 65535) $errors[] = 'Description is too long.';
        if (!in_array($property_type, ['House', 'Apartment', 'Land', 'Commercial', 'Townhouse'], true)) $errors[] = 'Choose a valid property type.';
        if (!in_array($listing_type, ['Sale', 'Rent'], true)) $errors[] = 'Choose a valid listing type.';
        if (!is_numeric($price) || (float)$price <= 0 || (float)$price > 9999999999.99) $errors[] = 'Valid price is required.';
        if ($bedrooms === false || $bedrooms < 0 || $bathrooms === false || $bathrooms < 0) $errors[] = 'Bedrooms and bathrooms must be zero or greater.';
        if (!is_numeric($size_sqm) || (float)$size_sqm < 0 || (float)$size_sqm > 99999999.99) $errors[] = 'Enter a valid property size.';

        $imageName = $property['image'];
        $newImageName = null;
        if (!$errors) {
            $newImageName = save_property_image($_FILES['image'] ?? null, $imageError);
            if ($newImageName === false) {
                $errors[] = $imageError;
            } elseif ($newImageName !== null) {
                $imageName = $newImageName;
            }
        }

        if (!$errors) {
            $price = (float)$price;
            $size_sqm = (float)$size_sqm;
            $stmt = $conn->prepare("UPDATE properties SET title=?, description=?, property_type=?, listing_type=?, price=?, location=?, bedrooms=?, bathrooms=?, size_sqm=?, image=? WHERE id=?");
            $stmt->bind_param('ssssdsiidsi', $title, $description, $property_type, $listing_type, $price, $location, $bedrooms, $bathrooms, $size_sqm, $imageName, $id);
            if ($stmt->execute()) {
                if ($newImageName !== null) {
                    delete_property_image($property['image']);
                }
                $success = true;
                $property = array_merge($property, compact('title','description','property_type','listing_type','price','location','bedrooms','bathrooms','size_sqm'));
                $property['image'] = $imageName;
            } else {
                delete_property_image($newImageName);
                $errors[] = 'The property could not be updated. Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Edit Property | EswatiniHomes</title>
<style>
    :root{--primary:#0f5132;--primary-dark:#0a3622;--accent:#d4a017;--bg:#f6f7f5;}
    *{box-sizing:border-box;margin:0;padding:0;}
    body{font-family:'Segoe UI',Arial,sans-serif;background:var(--bg);color:#222;}
    header{background:linear-gradient(135deg,var(--primary),var(--primary-dark));color:#fff;padding:18px 30px;display:flex;justify-content:space-between;align-items:center;}
    header .logo{font-size:22px;font-weight:700;}
    header .logo span{color:var(--accent);}
    nav a{color:#fff;text-decoration:none;margin-left:20px;font-size:15px;}
    .container{max-width:700px;margin:40px auto;padding:0 20px 60px;}
    .form-box{background:#fff;padding:30px;border-radius:10px;box-shadow:0 3px 12px rgba(0,0,0,.08);}
    h1{margin-bottom:20px;color:var(--primary-dark);}
    label{display:block;margin:14px 0 6px;font-weight:600;font-size:14px;}
    input, select, textarea{width:100%;padding:10px 12px;border:1px solid #ddd;border-radius:6px;font-size:14px;font-family:inherit;}
    textarea{resize:vertical;min-height:100px;}
    .row{display:flex;gap:14px;}
    .row > div{flex:1;}
    button{margin-top:22px;background:var(--primary);color:#fff;border:none;padding:12px 26px;border-radius:6px;cursor:pointer;font-weight:600;font-size:15px;}
    button:hover{background:var(--primary-dark);}
    .alert{padding:12px 16px;border-radius:6px;margin-bottom:16px;font-size:14px;}
    .alert.error{background:#fdecea;color:#b00020;}
    .alert.success{background:#e6f4ea;color:#0f5132;}
    .current-img{max-width:200px;border-radius:8px;margin-bottom:10px;display:block;}
</style>
</head>
<body>
<header>
    <div class="logo">Eswatini<span>Homes</span></div>
    <nav>
        <a href="../index.php">Home</a>
        <a href="../admin/dashboard.php">Admin Dashboard</a>
        <a href="../auth/logout.php">Logout</a>
    </nav>
</header>

<div class="container">
    <div class="form-box">
        <h1>Edit Property</h1>

        <?php if ($success): ?><div class="alert success">Property updated successfully.</div><?php endif; ?>
        <?php foreach ($errors as $err): ?><div class="alert error"><?= htmlspecialchars($err) ?></div><?php endforeach; ?>

        <?php if (property_image_exists($property['image'])): ?>
            <img class="current-img" src="<?= htmlspecialchars(property_image_url($property['image'])) ?>" alt="Current image">
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">
            <input type="hidden" name="id" value="<?= $property['id'] ?>">

            <label>Property Title</label>
            <input type="text" name="title" required value="<?= htmlspecialchars($property['title']) ?>">

            <label>Description</label>
            <textarea name="description"><?= htmlspecialchars($property['description']) ?></textarea>

            <div class="row">
                <div>
                    <label>Property Type</label>
                    <select name="property_type">
                        <?php foreach (['House','Apartment','Land','Commercial','Townhouse'] as $t): ?>
                            <option value="<?= $t ?>" <?= $property['property_type'] === $t ? 'selected' : '' ?>><?= $t ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label>Listing Type</label>
                    <select name="listing_type">
                        <option value="Sale" <?= $property['listing_type'] === 'Sale' ? 'selected' : '' ?>>For Sale</option>
                        <option value="Rent" <?= $property['listing_type'] === 'Rent' ? 'selected' : '' ?>>For Rent</option>
                    </select>
                </div>
            </div>

            <label>Price (Emalangeni)</label>
            <input type="number" step="0.01" name="price" required value="<?= htmlspecialchars($property['price']) ?>">

            <label>Location</label>
            <input type="text" name="location" required value="<?= htmlspecialchars($property['location']) ?>">

            <div class="row">
                <div>
                    <label>Bedrooms</label>
                    <input type="number" name="bedrooms" min="0" value="<?= (int)$property['bedrooms'] ?>">
                </div>
                <div>
                    <label>Bathrooms</label>
                    <input type="number" name="bathrooms" min="0" value="<?= (int)$property['bathrooms'] ?>">
                </div>
                <div>
                    <label>Size (m²)</label>
                    <input type="number" step="0.01" name="size_sqm" min="0" value="<?= (float)$property['size_sqm'] ?>">
                </div>
            </div>

            <label>Replace Image (optional)</label>
            <input type="file" name="image" accept=".jpg,.jpeg,.png,.webp">

            <button type="submit">Update Property</button>
        </form>
    </div>
</div>

</body>
</html>
