# EswatiniHomes – Property Listing Website

A PHP and MySQL property-listing application with public search, enquiries, account roles, listing moderation, and agent deal tracking. The interface styles and scripts are embedded in the PHP pages.

## Features

- Search and filter approved listings, with pagination
- Dedicated sale and rental pages, property details with assigned agent contacts, and payment calculator
- Boxicons for property details, search, contact, and navigation icons
- Public listing submissions with image validation and administrator approval
- User registration, administrator and agent roles, and CSRF-protected state-changing forms
- Administrator tools for listings, enquiries, accounts, and listing moderation
- Agent dashboard for completed deals and estimated commissions

## Project layout

```
property-listing/
├── admin/dashboard.php
├── assets/                # Hero and representative listing photos
│   └── listings/
├── auth/                 # Login, registration, logout
├── functions/            # Property add, edit, delete, and detail flows
├── include/config.php    # Database connection and shared helpers
├── pages/                # Sale, rent, calculator, and agent pages
├── uploads/              # Validated listing images
├── database.sql
├── index.php
└── README.md
```

## Setup

1. **Requirements:** PHP 7.4+ with `mysqli`, MySQL/MariaDB, and Apache/Nginx (XAMPP works).
2. Import `database.sql` using phpMyAdmin or the MySQL command line. The script creates the database, schema, and four sample listings. It does **not** create a default administrator.
3. Configure the database constants in `include/config.php` for your local environment.
4. Ensure the web server can write to `uploads/`. Keep PHP execution disabled in that directory in production.
5. Open `http://localhost/property-listing/index.php`.
6. Create the first administrator directly in the database. Generate a password hash with PHP:

   ```powershell
   C:\xampp\php\php.exe -r "echo password_hash('replace-with-a-strong-password', PASSWORD_DEFAULT), PHP_EOL;"
   ```

   Insert it into the `users` table, replacing the hash and username:

   ```sql
   INSERT INTO users (username, password, role)
   VALUES ('site-admin', '$2y$...paste-generated-hash...', 'admin');
   ```

   Use a unique, strong password and do not expose the hash-generation command or database to the public. Public registration only creates `user` accounts; administrators can assign agent or administrator roles from the dashboard.

## Existing installations

Back up the database before applying schema changes. The updated `database.sql` describes the complete schema for new installations; `CREATE TABLE IF NOT EXISTS` does not alter existing tables. Apply the following migration once to an existing database:

```sql
ALTER TABLE properties
    ADD COLUMN status ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
    ADD INDEX idx_properties_public (status, listing_type, featured, created_at),
    ADD INDEX idx_properties_type_price (status, property_type, price);

UPDATE properties SET status = 'Approved';
```

The migration marks existing listings as approved to preserve their visibility. To add per-listing agent contacts to an existing installation, apply this migration once after the status migration:

```sql
CREATE TABLE IF NOT EXISTS agents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    role VARCHAR(100) NOT NULL,
    email VARCHAR(190) NOT NULL UNIQUE,
    phone VARCHAR(40) NOT NULL
);

INSERT INTO agents (name, role, email, phone) VALUES
('Noncedo Vilakati', 'Estate Agent', 'nooncedo@gmail.com', '+268790123045'),
('Sibusiso Mhlanga', 'Estate Agent', 'Sibi@gmail.com', '+2687894321')
ON DUPLICATE KEY UPDATE name = VALUES(name), role = VALUES(role), phone = VALUES(phone);

ALTER TABLE properties
    ADD COLUMN agent_id INT DEFAULT NULL,
    ADD INDEX idx_properties_agent (agent_id),
    ADD CONSTRAINT fk_properties_agent
        FOREIGN KEY (agent_id) REFERENCES agents(id) ON DELETE SET NULL;

UPDATE properties p
JOIN agents a ON a.email = 'nooncedo@gmail.com'
SET p.agent_id = a.id;

UPDATE properties p
JOIN agents a ON a.email = 'Sibi@gmail.com'
SET p.agent_id = a.id
WHERE p.title = 'Prime Commercial Plot';
```

This assigns Sibusiso Mhlanga to “Prime Commercial Plot” and Noncedo Vilakati to the other existing listings. New listings default to Noncedo. For an existing installation, first create a replacement administrator in `users` using the setup steps above. If the legacy `admins` table still has the bundled default account, remove that account with `DELETE FROM admins WHERE username = 'admin';`. Do this only if that row still uses the bundled credentials. The application continues to support the legacy table for backward compatibility; remove all bundled default administrator accounts before deployment.

## Sample listing photos

These are illustrative stock photos, not photos of the listed Eswatini properties. The site labels them as illustrative and displays the photo credit/license beside each image.

- `modern-family-home.jpg` — [Shixart1985, Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Modern_house_exterior_with_red_roof_and_landscaped_garden_under_clear_blue_sky.jpg), [CC BY 2.0](https://creativecommons.org/licenses/by/2.0/).
- `cozy-apartment.jpg` — [Lo, Wikimedia Commons](https://commons.wikimedia.org/wiki/File:The_living_room_that_needs_houseplants.jpg), [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/).
- `commercial-plot.jpg` — [NikosLikomitros, Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Vacant_land_after_demolition.jpg), [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/).
- `luxury-townhouse.jpg` — [Scott Frances, Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Eastside_Townhouse_exterior.jpg), public domain.
- `double-story-house.jpg` — [Tracey Nicholls / CSIRO, Wikimedia Commons](https://commons.wikimedia.org/wiki/File:CSIRO_ScienceImage_2939_Two_Storey_Brick_Home.jpg), [CC BY 3.0](https://creativecommons.org/licenses/by/3.0/).

## Manual smoke checks

- Submit a listing while signed out; it should remain pending and not appear in public search or details until approved.
- Approve that listing from the administrator dashboard and confirm it appears in search and on the sale/rent page.
- Submit an enquiry from an approved listing and update its status in the administrator dashboard.
- Upload valid JPG, PNG, and WebP images, then try a renamed non-image and an oversized file; invalid uploads should be rejected.
- Try public search filters and navigate to another listing page; dashboard sections should also paginate when they have more than one page.
- Open the logout page with GET and confirm the session stays active; submit its CSRF-protected POST form to sign out.
