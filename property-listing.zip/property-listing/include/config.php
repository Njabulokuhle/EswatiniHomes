<?php
// ==========================================
// Database Configuration
// ==========================================
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'property_listing');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

session_start();

function currency($amount) {
    return 'E ' . number_format($amount, 2);
}

function is_logged_in() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function is_user_logged_in() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'user';
}

function app_url($path = '') {
    $scriptDirectory = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
    $appDirectory = preg_replace('#/(admin|auth|functions|pages)$#', '', $scriptDirectory);

    return rtrim($appDirectory, '/') . '/' . ltrim($path, '/');
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: ' . app_url('auth/login.php'));
        exit;
    }
}

function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function verify_csrf_token($token) {
    return is_string($token)
        && isset($_SESSION['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], $token);
}

function property_image_is_builtin($image) {
    return is_string($image) && in_array($image, [
        'modern-family-home.jpg',
        'cozy-apartment.jpg',
        'commercial-plot.jpg',
        'luxury-townhouse.jpg',
        'double-story-house.jpg',
    ], true);
}

function property_image_attribution($image) {
    $attributions = [
        'modern-family-home.jpg' => [
            'title' => 'Modern house exterior with red roof and landscaped garden under clear blue sky',
            'author' => 'Shixart1985',
            'source' => 'https://commons.wikimedia.org/wiki/File:Modern_house_exterior_with_red_roof_and_landscaped_garden_under_clear_blue_sky.jpg',
            'license' => 'CC BY 2.0',
            'license_url' => 'https://creativecommons.org/licenses/by/2.0/',
        ],
        'cozy-apartment.jpg' => [
            'title' => 'The living room that needs houseplants',
            'author' => 'Lo',
            'source' => 'https://commons.wikimedia.org/wiki/File:The_living_room_that_needs_houseplants.jpg',
            'license' => 'CC0 1.0',
            'license_url' => 'https://creativecommons.org/publicdomain/zero/1.0/',
        ],
        'commercial-plot.jpg' => [
            'title' => 'Vacant land after demolition',
            'author' => 'NikosLikomitros',
            'source' => 'https://commons.wikimedia.org/wiki/File:Vacant_land_after_demolition.jpg',
            'license' => 'CC0 1.0',
            'license_url' => 'https://creativecommons.org/publicdomain/zero/1.0/',
        ],
        'luxury-townhouse.jpg' => [
            'title' => 'Eastside Townhouse exterior',
            'author' => 'Scott Frances',
            'source' => 'https://commons.wikimedia.org/wiki/File:Eastside_Townhouse_exterior.jpg',
            'license' => 'Public domain',
            'license_url' => 'https://commons.wikimedia.org/wiki/File:Eastside_Townhouse_exterior.jpg',
        ],
        'double-story-house.jpg' => [
            'title' => 'CSIRO ScienceImage 2939 Two Storey Brick Home',
            'author' => 'Tracey Nicholls / CSIRO',
            'source' => 'https://commons.wikimedia.org/wiki/File:CSIRO_ScienceImage_2939_Two_Storey_Brick_Home.jpg',
            'license' => 'CC BY 3.0',
            'license_url' => 'https://creativecommons.org/licenses/by/3.0/',
        ],
    ];

    return is_string($image) ? ($attributions[$image] ?? null) : null;
}

function property_image_url($image) {
    if (property_image_is_builtin($image)) {
        return app_url('assets/listings/' . $image);
    }

    if (is_string($image) && preg_match('/\A(?:[a-f0-9]{32}\.(jpg|png|webp)|prop_[A-Za-z0-9_-]+\.(jpg|jpeg|png|webp))\z/', $image)) {
        return app_url('uploads/' . $image);
    }

    return null;
}

function property_image_exists($image) {
    if (property_image_is_builtin($image)) {
        return is_file(__DIR__ . '/../assets/listings/' . $image);
    }

    if (property_image_url($image) !== null) {
        return is_file(__DIR__ . '/../uploads/' . $image);
    }

    return false;
}

function request_string($source, $key, $default = '') {
    return isset($source[$key]) && is_string($source[$key]) ? $source[$key] : $default;
}

function save_property_image($upload, &$error) {
    $error = '';
    if (!is_array($upload) || !isset($upload['error'])) {
        return null;
    }

    if ($upload['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if ($upload['error'] !== UPLOAD_ERR_OK) {
        $error = 'The image upload failed. Please try again.';
        return false;
    }
    if (!isset($upload['size'], $upload['tmp_name']) || $upload['size'] > 5 * 1024 * 1024) {
        $error = 'Image must be under 5MB.';
        return false;
    }

    $imageInfo = @getimagesize($upload['tmp_name']);
    $extensions = [
        IMAGETYPE_JPEG => 'jpg',
        IMAGETYPE_PNG => 'png',
        IMAGETYPE_WEBP => 'webp',
    ];
    if (!$imageInfo || !isset($extensions[$imageInfo[2]])) {
        $error = 'Image must be a valid JPG, PNG or WebP file.';
        return false;
    }
    if ($imageInfo[0] > 8000 || $imageInfo[1] > 8000 || $imageInfo[0] * $imageInfo[1] > 40000000) {
        $error = 'Image dimensions must not exceed 8,000 pixels per side or 40 megapixels.';
        return false;
    }

    $imageName = bin2hex(random_bytes(16)) . '.' . $extensions[$imageInfo[2]];
    $destination = __DIR__ . '/../uploads/' . $imageName;
    if (!move_uploaded_file($upload['tmp_name'], $destination)) {
        $error = 'The image could not be saved. Check that the uploads folder is writable.';
        return false;
    }

    return $imageName;
}

function delete_property_image($imageName) {
    if (is_string($imageName) && preg_match('/\A(?:[a-f0-9]{32}\.(jpg|png|webp)|prop_[A-Za-z0-9_-]+\.(jpg|jpeg|png|webp))\z/', $imageName)) {
        $imagePath = __DIR__ . '/../uploads/' . $imageName;
        if (is_file($imagePath) && !unlink($imagePath)) {
            error_log('Unable to remove property image: ' . $imageName);
        }
    }
}
?>
