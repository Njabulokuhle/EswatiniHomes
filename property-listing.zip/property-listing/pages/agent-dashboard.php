<?php
require_once __DIR__ . '/../include/config.php';

if (($_SESSION['role'] ?? '') !== 'agent') {
    header('Location: ' . (is_logged_in() || is_user_logged_in() ? '../index.php' : '../auth/login.php'));
    exit;
}

$error = '';
$notice = '';
$agentId = (int)($_SESSION['account_id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? null)) {
        http_response_code(400);
        exit('Invalid request token. Refresh the page and try again.');
    }

    if (($_POST['action'] ?? '') === 'add_deal') {
        $propertyTitle = trim(request_string($_POST, 'property_title'));
        $dealType = request_string($_POST, 'deal_type');
        $dealAmount = request_string($_POST, 'deal_amount');
        $commissionRate = request_string($_POST, 'commission_rate');
        $closedOn = request_string($_POST, 'closed_on');
        $closeDate = DateTime::createFromFormat('!Y-m-d', $closedOn);
        $validDate = $closeDate && $closeDate->format('Y-m-d') === $closedOn;

        if ($propertyTitle === '' || strlen($propertyTitle) > 150) {
            $error = 'Enter a property name or address (up to 150 characters).';
        } elseif (!in_array($dealType, ['Sale', 'Rent'], true)) {
            $error = 'Choose whether the completed deal was a sale or rental.';
        } elseif (!is_numeric($dealAmount) || (float)$dealAmount <= 0 || (float)$dealAmount > 9999999999.99) {
            $error = 'Enter a valid deal amount greater than zero.';
        } elseif (!is_numeric($commissionRate) || (float)$commissionRate < 0 || (float)$commissionRate > 100) {
            $error = 'Commission rate must be between 0 and 100 percent.';
        } elseif (!$validDate || $closedOn > date('Y-m-d')) {
            $error = 'Enter a valid completion date that is not in the future.';
        } else {
            $dealAmount = (float)$dealAmount;
            $commissionRate = (float)$commissionRate;
            $commissionAmount = round($dealAmount * $commissionRate / 100, 2);
            $stmt = $conn->prepare('INSERT INTO agent_deals (agent_id, property_title, deal_type, deal_amount, commission_rate, commission_amount, closed_on) VALUES (?, ?, ?, ?, ?, ?, ?)');
            $stmt->bind_param('issddds', $agentId, $propertyTitle, $dealType, $dealAmount, $commissionRate, $commissionAmount, $closedOn);

            if ($stmt->execute()) {
                header('Location: agent-dashboard.php?saved=1');
                exit;
            }
            $error = 'The deal could not be saved. Please try again.';
        }
    } elseif (($_POST['action'] ?? '') === 'delete_deal') {
        $dealId = (int)($_POST['deal_id'] ?? 0);
        $stmt = $conn->prepare('DELETE FROM agent_deals WHERE id = ? AND agent_id = ?');
        $stmt->bind_param('ii', $dealId, $agentId);
        $stmt->execute();
        header('Location: agent-dashboard.php?deleted=1');
        exit;
    }
}

if (isset($_GET['saved'])) $notice = 'Completed deal added.';
if (isset($_GET['deleted'])) $notice = 'Deal removed.';

$stmt = $conn->prepare("SELECT COUNT(*) AS deal_count, COALESCE(SUM(commission_amount), 0) AS total_commission, COALESCE(SUM(CASE WHEN deal_type = 'Sale' THEN deal_amount ELSE 0 END), 0) AS sale_volume, COALESCE(SUM(CASE WHEN deal_type = 'Rent' THEN deal_amount ELSE 0 END), 0) AS rental_volume FROM agent_deals WHERE agent_id = ?");
$stmt->bind_param('i', $agentId);
$stmt->execute();
$summary = $stmt->get_result()->fetch_assoc();
$stmt = $conn->prepare('SELECT id, property_title, deal_type, deal_amount, commission_rate, commission_amount, closed_on FROM agent_deals WHERE agent_id = ? ORDER BY closed_on DESC, id DESC');
$stmt->bind_param('i', $agentId);
$stmt->execute();
$deals = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$token = csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Agent Dashboard | EswatiniHomes</title>
<style>
    :root{--green:#164b36;--green-dark:#103727;--gold:#d6a52b;--ink:#202a25;--muted:#68736c;--paper:#f3f5f1;--line:#dce2dc;--white:#fff;--red:#a33a32;}
    *{box-sizing:border-box;margin:0;padding:0;}
    body{font-family:'Segoe UI',Arial,sans-serif;background:var(--paper);color:var(--ink);}
    header{background:var(--green-dark);color:var(--white);padding:16px 28px;display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap;}
    .brand{font-weight:700;font-size:20px;}.brand span{color:var(--gold);}
    nav{display:flex;align-items:center;gap:18px;flex-wrap:wrap;}nav a{color:#fff;text-decoration:none;font-size:14px;}nav a:hover{color:var(--gold);}
    main{max-width:1220px;margin:0 auto;padding:34px 24px 60px;}
    .page-head{display:flex;justify-content:space-between;align-items:end;gap:20px;flex-wrap:wrap;margin-bottom:22px;}
    h1{font-size:28px;color:var(--green-dark);margin-bottom:5px;}.page-head p{font-size:14px;color:var(--muted);}
    .metrics{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));background:#fff;border-block:1px solid var(--line);margin-bottom:26px;}
    .metric{padding:16px 18px;border-right:1px solid var(--line);}.metric:last-child{border-right:0;}.metric span{display:block;color:var(--muted);font-size:11px;text-transform:uppercase;letter-spacing:.04em;}.metric strong{display:block;color:var(--green-dark);font-size:24px;margin-top:5px;}
    .layout{display:grid;grid-template-columns:minmax(280px,.75fr) minmax(0,1.6fr);gap:20px;align-items:start;}
    .section{background:#fff;border-top:3px solid var(--green);padding:20px;}.section h2{font-size:18px;color:var(--green-dark);margin-bottom:5px;}.section>p{font-size:13px;color:var(--muted);margin-bottom:16px;}
    label{display:block;font-size:13px;font-weight:600;margin:13px 0 6px;}input,select{width:100%;height:41px;border:1px solid #cbd4cd;border-radius:4px;padding:8px 10px;font:inherit;color:var(--ink);background:#fff;}input:focus,select:focus{outline:2px solid #82a994;outline-offset:1px;}
    .row{display:grid;grid-template-columns:1fr 1fr;gap:12px;}button{border:0;border-radius:4px;padding:10px 13px;background:var(--green);color:#fff;font:600 13px 'Segoe UI',Arial,sans-serif;cursor:pointer;}button:hover{background:var(--green-dark);}.submit{width:100%;margin-top:18px;}
    .notice{padding:11px 14px;background:#e3f1e7;color:#245a35;border-left:4px solid #438258;margin-bottom:17px;font-size:14px;}.notice.error{background:#f9e9e6;color:var(--red);border-color:var(--red);}
    .table-wrap{overflow-x:auto;}table{width:100%;border-collapse:collapse;text-align:left;font-size:13px;min-width:660px;}th{font-size:10px;text-transform:uppercase;color:var(--muted);letter-spacing:.04em;}th,td{padding:11px 9px;border-top:1px solid #e8ece8;vertical-align:middle;}td strong{font-size:13px;}td small{display:block;color:var(--muted);margin-top:3px;}.tag{display:inline-block;padding:4px 7px;background:#e8eee9;color:var(--green-dark);font-size:11px;font-weight:600;}
    .danger{background:#fff;color:var(--red);border:1px solid #e4c8c4;padding:7px 9px;}.danger:hover{background:#f9e9e6;}.empty{text-align:center;color:var(--muted);padding:24px;}
    @media(max-width:850px){.layout{grid-template-columns:1fr;}.metrics{grid-template-columns:repeat(2,minmax(0,1fr));}.metric:nth-child(2){border-right:0;}.metric:nth-child(-n+2){border-bottom:1px solid var(--line);}}
    @media(max-width:500px){main{padding:25px 14px 45px;}header{padding:14px 16px;}nav{gap:12px;}h1{font-size:24px;}.section{padding:16px 13px;}.metric{padding:13px;}.metric strong{font-size:20px;}}
</style>
</head>
<body>
<header>
    <div class="brand">Eswatini<span>Homes</span> / Agent</div>
    <nav><a href="../index.php">Home</a><a href="sale.php">For sale</a><a href="rent.php">For rent</a><a href="calculator.php">Payment calculator</a><a href="../auth/logout.php">Sign out</a></nav>
</header>
<main>
    <div class="page-head">
        <div><h1>Agent dashboard</h1><p>Track completed sales, rentals, and earned commission, <?= htmlspecialchars($_SESSION['username'] ?? '') ?>.</p></div>
    </div>
    <?php if ($notice): ?><div class="notice" role="status"><?= htmlspecialchars($notice) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="notice error" role="alert"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    <section class="metrics" aria-label="Your deal totals">
        <div class="metric"><span>Completed deals</span><strong><?= (int)$summary['deal_count'] ?></strong></div>
        <div class="metric"><span>Total commission</span><strong><?= htmlspecialchars(currency($summary['total_commission'])) ?></strong></div>
        <div class="metric"><span>Sale volume</span><strong><?= htmlspecialchars(currency($summary['sale_volume'])) ?></strong></div>
        <div class="metric"><span>Rental volume</span><strong><?= htmlspecialchars(currency($summary['rental_volume'])) ?></strong></div>
    </section>
    <div class="layout">
        <section class="section">
            <h2>Record a completed deal</h2>
            <p>Commission is estimated from the deal amount and rate you enter.</p>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($token) ?>">
                <input type="hidden" name="action" value="add_deal">
                <label for="propertyTitle">Property name or address</label>
                <input id="propertyTitle" name="property_title" maxlength="150" required value="<?= htmlspecialchars(request_string($_POST, 'property_title')) ?>">
                <div class="row">
                    <div><label for="dealType">Deal type</label><select id="dealType" name="deal_type" required><option value="Sale">Sale</option><option value="Rent">Rental</option></select></div>
                    <div><label for="closedOn">Completion date</label><input id="closedOn" name="closed_on" type="date" max="<?= date('Y-m-d') ?>" value="<?= htmlspecialchars(request_string($_POST, 'closed_on', date('Y-m-d'))) ?>" required></div>
                </div>
                <div class="row">
                    <div><label for="dealAmount">Deal amount (E)</label><input id="dealAmount" name="deal_amount" type="number" min="0.01" step="0.01" required value="<?= htmlspecialchars(request_string($_POST, 'deal_amount')) ?>"></div>
                    <div><label for="commissionRate">Commission rate (%)</label><input id="commissionRate" name="commission_rate" type="number" min="0" max="100" step="0.01" required value="<?= htmlspecialchars(request_string($_POST, 'commission_rate')) ?>"></div>
                </div>
                <p id="commissionPreview" class="hint" aria-live="polite">Estimated commission: E 0.00</p>
                <button class="submit" type="submit">Add completed deal</button>
            </form>
        </section>
        <section class="section">
            <h2>Completed deals</h2>
            <p>Your recorded sale and rental transactions.</p>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>Property</th><th>Type</th><th>Amount</th><th>Rate</th><th>Commission</th><th>Closed</th><th></th></tr></thead>
                    <tbody>
                    <?php if (!$deals): ?>
                        <tr><td class="empty" colspan="7">No completed deals recorded yet.</td></tr>
                    <?php else: foreach ($deals as $deal): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($deal['property_title']) ?></strong></td>
                            <td><span class="tag"><?= htmlspecialchars($deal['deal_type']) ?></span></td>
                            <td><?= htmlspecialchars(currency($deal['deal_amount'])) ?></td>
                            <td><?= htmlspecialchars(number_format((float)$deal['commission_rate'], 2)) ?>%</td>
                            <td><strong><?= htmlspecialchars(currency($deal['commission_amount'])) ?></strong></td>
                            <td><?= htmlspecialchars(date('M j, Y', strtotime($deal['closed_on']))) ?></td>
                            <td><form method="POST" onsubmit="return confirm('Remove this deal record?');"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($token) ?>"><input type="hidden" name="action" value="delete_deal"><input type="hidden" name="deal_id" value="<?= (int)$deal['id'] ?>"><button class="danger" type="submit" aria-label="Remove <?= htmlspecialchars($deal['property_title']) ?>">Remove</button></form></td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>
</main>
<script>
    const amountInput = document.getElementById('dealAmount');
    const rateInput = document.getElementById('commissionRate');
    const preview = document.getElementById('commissionPreview');
    const commissionCurrency = new Intl.NumberFormat('en-SZ', {minimumFractionDigits: 2, maximumFractionDigits: 2});
    function updateCommissionPreview() {
        const amount = Math.max(0, Number(amountInput.value) || 0);
        const rate = Math.max(0, Number(rateInput.value) || 0);
        preview.textContent = 'Estimated commission: E ' + commissionCurrency.format(amount * rate / 100);
    }
    amountInput.addEventListener('input', updateCommissionPreview);
    rateInput.addEventListener('input', updateCommissionPreview);
    updateCommissionPreview();
</script>
</body>
</html>