<?php
require_once __DIR__ . '/../include/config.php';

$listingType = defined('LISTING_TYPE') ? LISTING_TYPE : 'Sale';
$countStmt = $conn->prepare("SELECT COUNT(*) AS total FROM properties WHERE status = 'Approved' AND listing_type = ?");
$countStmt->bind_param('s', $listingType);
$countStmt->execute();
$totalProperties = (int)$countStmt->get_result()->fetch_assoc()['total'];
$perPage = 12;
$totalPages = max(1, (int)ceil($totalProperties / $perPage));
$page = filter_var($_GET['page'] ?? 1, FILTER_VALIDATE_INT);
$page = $page === false || $page < 1 ? 1 : min($page, $totalPages);
$offset = ($page - 1) * $perPage;
$stmt = $conn->prepare("SELECT * FROM properties WHERE status = 'Approved' AND listing_type = ? ORDER BY featured DESC, created_at DESC LIMIT ? OFFSET ?");
$stmt->bind_param('sii', $listingType, $perPage, $offset);
$stmt->execute();
$properties = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$heading = $listingType === 'Sale' ? 'Properties for sale' : 'Properties for rent';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($heading) ?> | EswatiniHomes</title>
<link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
<style>
    :root{--green:#164b36;--green-dark:#103727;--gold:#d6a52b;--ink:#202a25;--muted:#68736c;--paper:#f3f5f1;--line:#dce2dc;--white:#fff;}
    *{box-sizing:border-box;margin:0;padding:0;}
    body{font-family:'Segoe UI',Arial,sans-serif;background:var(--paper);color:var(--ink);}
    header{background:var(--green-dark);color:var(--white);padding:16px 28px;display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap;}
    .brand{font-weight:700;font-size:20px;}.brand span{color:var(--gold);}
    nav{display:flex;align-items:center;gap:18px;flex-wrap:wrap;}nav a{color:#fff;text-decoration:none;font-size:14px;}nav a:hover{color:var(--gold);}
    main{max-width:1200px;margin:0 auto;padding:38px 24px 65px;}
    .page-head{display:flex;justify-content:space-between;align-items:end;gap:20px;margin-bottom:22px;flex-wrap:wrap;}
    h1{font-size:29px;color:var(--green-dark);margin-bottom:5px;}.page-head p{font-size:14px;color:var(--muted);}
    .switch{display:flex;gap:8px;}.switch a{padding:9px 13px;border:1px solid var(--line);color:var(--green-dark);background:#fff;text-decoration:none;font-size:13px;font-weight:600;}
    .switch a.active{background:var(--green);border-color:var(--green);color:#fff;}
    .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:18px;}
    .property{background:#fff;border-bottom:2px solid var(--line);}.property img,.placeholder{width:100%;height:190px;object-fit:cover;background:#e5e9e4;display:flex;align-items:center;justify-content:center;color:var(--muted);font-size:13px;}
    .property-body{padding:16px;}.badge{display:inline-block;background:#e7efe9;color:var(--green-dark);font-size:11px;font-weight:700;padding:5px 8px;text-transform:uppercase;}
    h2{font-size:17px;margin:9px 0 5px;}.location{font-size:13px;color:var(--muted);}.price{font-size:19px;font-weight:700;color:var(--green-dark);margin:11px 0;}
    .icon-text{display:inline-flex;align-items:center;gap:4px;}.icon-text i{font-size:16px;line-height:1;}
    .details{display:flex;flex-wrap:wrap;gap:12px;font-size:12px;color:var(--muted);margin-bottom:15px;}.view{display:inline-block;background:var(--green);color:#fff;text-decoration:none;padding:9px 13px;font-size:13px;font-weight:600;}
    .empty{padding:48px 20px;text-align:center;background:#fff;color:var(--muted);border-top:3px solid var(--green);}
    .pagination{display:flex;justify-content:center;align-items:center;gap:14px;margin-top:28px;color:var(--muted);font-size:14px;}
    .pagination a{color:var(--green);font-weight:600;text-decoration:none;}
    @media(max-width:600px){main{padding:26px 15px 45px;}h1{font-size:25px;}}
</style>
</head>
<body>
<header>
    <div class="brand">Eswatini<span>Homes</span></div>
    <nav>
        <a href="../index.php">Home</a>
        <a href="sale.php">For sale</a>
        <a href="rent.php">For rent</a>
        <a href="calculator.php">Payment calculator</a>
        <?php if (($_SESSION['role'] ?? '') === 'agent'): ?><a href="agent-dashboard.php">Agent dashboard</a><?php endif; ?>
        <?php if (is_logged_in() || is_user_logged_in() || (($_SESSION['role'] ?? '') === 'agent')): ?><a href="../auth/logout.php">Sign out</a><?php else: ?><a href="../auth/login.php">Sign in</a><?php endif; ?>
    </nav>
</header>
<main>
    <div class="page-head">
        <div><h1><?= htmlspecialchars($heading) ?></h1><p><?= $totalProperties ?> available listing<?= $totalProperties === 1 ? '' : 's' ?></p></div>
        <div class="switch"><a href="sale.php" class="<?= $listingType === 'Sale' ? 'active' : '' ?>">For sale</a><a href="rent.php" class="<?= $listingType === 'Rent' ? 'active' : '' ?>">For rent</a></div>
    </div>
    <?php if (!$properties): ?>
        <div class="empty">There are no properties listed <?= $listingType === 'Sale' ? 'for sale' : 'for rent' ?> right now.</div>
    <?php else: ?>
        <div class="grid">
            <?php foreach ($properties as $property): ?>
                <article class="property">
                    <?php if (property_image_exists($property['image'])): ?>
                        <img src="<?= htmlspecialchars(property_image_url($property['image'])) ?>" alt="<?= htmlspecialchars($property['title']) ?>">
                    <?php else: ?>
                        <div class="placeholder">No image available</div>
                    <?php endif; ?>
                    <div class="property-body">
                        <span class="badge"><?= htmlspecialchars($property['property_type']) ?></span>
                        <h2><?= htmlspecialchars($property['title']) ?></h2>
                        <p class="location icon-text"><i class="bx bx-map-pin" aria-hidden="true"></i><?= htmlspecialchars($property['location']) ?></p>
                        <p class="price"><?= htmlspecialchars(currency($property['price'])) ?><?= $listingType === 'Rent' ? ' / month' : '' ?></p>
                        <p class="details">
                            <span class="icon-text"><i class="bx bx-bed" aria-hidden="true"></i><?= (int)$property['bedrooms'] ?> bedrooms</span>
                            <span class="icon-text"><i class="bx bx-bath" aria-hidden="true"></i><?= (int)$property['bathrooms'] ?> bathrooms</span>
                            <span class="icon-text"><i class="bx bx-ruler" aria-hidden="true"></i><?= htmlspecialchars((string)$property['size_sqm']) ?> m²</span>
                        </p>
                        <a class="view" href="../functions/view.php?id=<?= (int)$property['id'] ?>">View property</a>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <?php if ($totalPages > 1): ?>
        <nav class="pagination" aria-label="Listing pages">
            <?php if ($page > 1): ?><a href="?page=<?= $page - 1 ?>">Previous</a><?php endif; ?>
            <span>Page <?= $page ?> of <?= $totalPages ?></span>
            <?php if ($page < $totalPages): ?><a href="?page=<?= $page + 1 ?>">Next</a><?php endif; ?>
        </nav>
    <?php endif; ?>
</main>
</body>
</html>