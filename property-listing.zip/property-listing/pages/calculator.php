<?php require_once __DIR__ . '/../include/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Payment Calculator | EswatiniHomes</title>
<style>
    :root{--green:#164b36;--green-dark:#103727;--gold:#d6a52b;--ink:#202a25;--muted:#68736c;--paper:#f3f5f1;--line:#dce2dc;--white:#fff;}
    *{box-sizing:border-box;margin:0;padding:0;}
    body{font-family:'Segoe UI',Arial,sans-serif;background:var(--paper);color:var(--ink);}
    header{background:var(--green-dark);color:var(--white);padding:16px 28px;display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap;}
    .brand{font-weight:700;font-size:20px;}.brand span{color:var(--gold);}
    nav{display:flex;align-items:center;gap:18px;flex-wrap:wrap;}nav a{color:#fff;text-decoration:none;font-size:14px;}nav a:hover{color:var(--gold);}
    main{max-width:1080px;margin:0 auto;padding:42px 24px 70px;}
    .intro{margin-bottom:25px;}.eyebrow{color:var(--green);font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;}
    h1{font-size:30px;color:var(--green-dark);margin:7px 0;}.intro p{color:var(--muted);font-size:15px;}
    .calculator{display:grid;grid-template-columns:minmax(0,1.2fr) minmax(280px,.8fr);background:var(--white);border-top:4px solid var(--green);}
    .controls{padding:26px;border-right:1px solid var(--line);}
    .tabs{display:flex;gap:5px;border-bottom:1px solid var(--line);margin-bottom:20px;}
    .tabs button{border:0;background:transparent;color:var(--muted);font:inherit;font-size:14px;font-weight:600;padding:10px 16px;border-bottom:3px solid transparent;cursor:pointer;}
    .tabs button[aria-selected="true"]{color:var(--green-dark);border-color:var(--gold);}
    .fields{display:grid;grid-template-columns:1fr 1fr;gap:16px;}.field.full{grid-column:1/-1;}
    label{display:block;font-size:13px;font-weight:600;margin-bottom:6px;}
    input{width:100%;height:43px;padding:9px 11px;border:1px solid #cbd4cd;border-radius:4px;font:inherit;color:var(--ink);}
    input:focus{outline:2px solid #82a994;outline-offset:1px;}
    .hint{font-size:12px;color:var(--muted);margin-top:5px;}
    .results{padding:28px;background:#f9faf8;display:flex;flex-direction:column;justify-content:center;}
    .results h2{font-size:17px;color:var(--green-dark);margin-bottom:5px;}.results>p{font-size:13px;color:var(--muted);margin-bottom:18px;}
    .primary-result{padding:17px 0;border-block:1px solid var(--line);}.primary-result span,.result-row span{display:block;color:var(--muted);font-size:12px;}
    .primary-result strong{display:block;color:var(--green-dark);font-size:29px;margin-top:3px;}
    .result-row{display:flex;justify-content:space-between;gap:16px;padding:12px 0;border-bottom:1px solid var(--line);font-size:13px;}
    .result-row strong{text-align:right;color:var(--ink);font-size:14px;}
    .disclaimer{font-size:11px;line-height:1.5;color:var(--muted);margin-top:17px;}
    [hidden]{display:none!important;}
    @media(max-width:720px){main{padding:30px 16px 50px;}.calculator{grid-template-columns:1fr;}.controls{border-right:0;border-bottom:1px solid var(--line);padding:20px;}.results{padding:22px;}}
    @media(max-width:430px){.fields{grid-template-columns:1fr;}.field.full{grid-column:auto;}h1{font-size:25px;}}
</style>
</head>
<body>
<header>
    <div class="brand">Eswatini<span>Homes</span></div>
    <nav>
        <a href="../index.php">Home</a>
        <a href="sale.php">For sale</a>
        <a href="rent.php">For rent</a>
        <a href="calculator.php">Payment calculator</a>
        <?php if (($_SESSION['role'] ?? '') === 'agent'): ?><a href="agent-dashboard.php">Agent dashboard</a><?php endif; ?>
        <?php if (is_logged_in() || is_user_logged_in() || (($_SESSION['role'] ?? '') === 'agent')): ?>
            <a href="../auth/logout.php">Sign out</a>
        <?php else: ?>
            <a href="../auth/login.php">Sign in</a>
        <?php endif; ?>
    </nav>
</header>
<main>
    <div class="intro">
        <span class="eyebrow">Plan your next move</span>
        <h1>Property payment calculator</h1>
        <p>Estimate monthly home-loan repayments or the cash needed to move into a rental.</p>
    </div>
    <section class="calculator" aria-label="Property payment calculator">
        <div class="controls">
            <div class="tabs" role="tablist" aria-label="Payment type">
                <button type="button" id="saleTab" role="tab" aria-selected="true" aria-controls="salePanel">Buying</button>
                <button type="button" id="rentTab" role="tab" aria-selected="false" aria-controls="rentPanel">Renting</button>
            </div>
            <div id="salePanel" role="tabpanel" aria-labelledby="saleTab">
                <div class="fields">
                    <div class="field full"><label for="salePrice">Property price (E)</label><input id="salePrice" type="number" min="1" step="1000" value="1200000"></div>
                    <div class="field"><label for="depositPercent">Deposit (%)</label><input id="depositPercent" type="number" min="0" max="100" step="0.5" value="10"></div>
                    <div class="field"><label for="interestRate">Annual interest rate (%)</label><input id="interestRate" type="number" min="0" max="100" step="0.1" value="10.5"></div>
                    <div class="field"><label for="loanYears">Loan term (years)</label><input id="loanYears" type="number" min="1" max="40" step="1" value="20"></div>
                    <div class="field"><label for="buyingFees">Other upfront costs (E)</label><input id="buyingFees" type="number" min="0" step="100" value="0"></div>
                </div>
            </div>
            <div id="rentPanel" role="tabpanel" aria-labelledby="rentTab" hidden>
                <div class="fields">
                    <div class="field full"><label for="monthlyRent">Monthly rent (E)</label><input id="monthlyRent" type="number" min="0" step="100" value="6500"></div>
                    <div class="field"><label for="depositMonths">Security deposit (months)</label><input id="depositMonths" type="number" min="0" max="24" step="1" value="1"></div>
                    <div class="field"><label for="advanceMonths">Rent paid in advance (months)</label><input id="advanceMonths" type="number" min="0" max="24" step="1" value="1"></div>
                    <div class="field full"><label for="rentalFees">Other move-in costs (E)</label><input id="rentalFees" type="number" min="0" step="100" value="0"></div>
                </div>
            </div>
        </div>
        <aside class="results" aria-live="polite">
            <h2 id="resultHeading">Your estimated home-loan payment</h2>
            <p id="resultDescription">Based on the figures entered. Your lender may use different terms.</p>
            <div id="saleResults">
                <div class="primary-result"><span>Estimated monthly repayment</span><strong id="monthlyPayment">E 0.00</strong></div>
                <div class="result-row"><span>Deposit</span><strong id="depositAmount">E 0.00</strong></div>
                <div class="result-row"><span>Estimated loan amount</span><strong id="loanAmount">E 0.00</strong></div>
                <div class="result-row"><span>Estimated cash upfront</span><strong id="saleUpfront">E 0.00</strong></div>
            </div>
            <div id="rentResults" hidden>
                <div class="primary-result"><span>Estimated move-in total</span><strong id="moveInTotal">E 0.00</strong></div>
                <div class="result-row"><span>Refundable security deposit</span><strong id="securityDeposit">E 0.00</strong></div>
                <div class="result-row"><span>Rent paid in advance</span><strong id="rentAdvance">E 0.00</strong></div>
                <div class="result-row"><span>Monthly rent</span><strong id="monthlyRentResult">E 0.00</strong></div>
            </div>
            <p class="disclaimer">Estimates only. Loan repayments exclude insurance, taxes, and lender fees. Confirm all amounts and terms with your bank or landlord.</p>
        </aside>
    </section>
</main>
<script>
    const currencyFormat = new Intl.NumberFormat('en-SZ', {minimumFractionDigits: 2, maximumFractionDigits: 2});
    const money = amount => 'E ' + currencyFormat.format(Number.isFinite(amount) ? amount : 0);
    const value = id => Math.max(0, Number(document.getElementById(id).value) || 0);
    const saleInputs = ['salePrice', 'depositPercent', 'interestRate', 'loanYears', 'buyingFees'];
    const rentInputs = ['monthlyRent', 'depositMonths', 'advanceMonths', 'rentalFees'];

    function updateCalculator() {
        const price = value('salePrice');
        const depositRate = Math.min(100, value('depositPercent')) / 100;
        const deposit = price * depositRate;
        const principal = price - deposit;
        const months = value('loanYears') * 12;
        const monthlyRate = value('interestRate') / 1200;
        const repayment = months > 0
            ? (monthlyRate === 0 ? principal / months : principal * monthlyRate / (1 - Math.pow(1 + monthlyRate, -months)))
            : 0;

        document.getElementById('monthlyPayment').textContent = money(repayment);
        document.getElementById('depositAmount').textContent = money(deposit);
        document.getElementById('loanAmount').textContent = money(principal);
        document.getElementById('saleUpfront').textContent = money(deposit + value('buyingFees'));

        const rent = value('monthlyRent');
        const security = rent * value('depositMonths');
        const advance = rent * value('advanceMonths');
        document.getElementById('moveInTotal').textContent = money(security + advance + value('rentalFees'));
        document.getElementById('securityDeposit').textContent = money(security);
        document.getElementById('rentAdvance').textContent = money(advance);
        document.getElementById('monthlyRentResult').textContent = money(rent);
    }

    function selectMode(mode) {
        const buying = mode === 'sale';
        document.getElementById('saleTab').setAttribute('aria-selected', String(buying));
        document.getElementById('rentTab').setAttribute('aria-selected', String(!buying));
        document.getElementById('salePanel').hidden = !buying;
        document.getElementById('rentPanel').hidden = buying;
        document.getElementById('saleResults').hidden = !buying;
        document.getElementById('rentResults').hidden = buying;
        document.getElementById('resultHeading').textContent = buying ? 'Your estimated home-loan payment' : 'Your estimated rental costs';
        document.getElementById('resultDescription').textContent = buying
            ? 'Based on the figures entered. Your lender may use different terms.'
            : 'Estimate your initial move-in amount and ongoing monthly rent.';
    }

    [...saleInputs, ...rentInputs].forEach(id => document.getElementById(id).addEventListener('input', updateCalculator));
    document.getElementById('saleTab').addEventListener('click', () => selectMode('sale'));
    document.getElementById('rentTab').addEventListener('click', () => selectMode('rent'));
    updateCalculator();
</script>
</body>
</html>