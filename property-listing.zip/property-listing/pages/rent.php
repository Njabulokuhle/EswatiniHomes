<?php
define('LISTING_TYPE', 'Rent');
require __DIR__ . '/listings.php';