<?php
define('LISTING_TYPE', 'Sale');
require __DIR__ . '/listings.php';