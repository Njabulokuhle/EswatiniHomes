<?php
require_once __DIR__ . '/../include/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? null)) {
        http_response_code(400);
        exit('Invalid request token. Refresh the page and try again.');
    }

    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $cookie = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $cookie['path'], $cookie['domain'], $cookie['secure'], $cookie['httponly']);
    }
    session_destroy();
    header('Location: ' . app_url('index.php'));
    exit;
}

if (!in_array($_SERVER['REQUEST_METHOD'], ['GET', 'HEAD'], true)) {
    http_response_code(405);
    header('Allow: GET, HEAD, POST');
    exit('Method not allowed.');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign Out | EswatiniHomes</title>
<style>
    body{font-family:Arial,sans-serif;background:#f6f7f5;color:#222;display:grid;place-items:center;min-height:100vh;margin:0;}
    main{background:#fff;padding:30px;border-radius:8px;box-shadow:0 3px 12px rgba(0,0,0,.08);text-align:center;}
    button{background:#0f5132;color:#fff;border:0;border-radius:5px;padding:10px 18px;font-size:15px;cursor:pointer;}
    a{color:#0f5132;margin-left:12px;}
</style>
</head>
<body>
<main>
    <h1>Sign out?</h1>
    <p>Are you sure you want to end your EswatiniHomes session?</p>
    <form method="POST" style="display:inline">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">
        <button type="submit">Sign out</button>
    </form>
    <a href="<?= htmlspecialchars(app_url('index.php')) ?>">Cancel</a>
</main>
</body>
</html>
