<?php require_once __DIR__ . '/../include/config.php';

$error = '';
$username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? null)) {
        $error = 'Your session expired. Refresh the page and try again.';
    } else {
        $username = trim(request_string($_POST, 'username'));
        $password = request_string($_POST, 'password');
        $confirmPassword = request_string($_POST, 'confirm_password');

        if (!preg_match('/^[A-Za-z0-9_]{3,50}$/', $username)) {
            $error = 'Username must be 3-50 characters and use only letters, numbers, or underscores.';
        } elseif (strlen($password) < 8) {
            $error = 'Password must be at least 8 characters.';
        } elseif ($password !== $confirmPassword) {
            $error = 'Passwords do not match.';
        } else {
            $stmt = $conn->prepare("SELECT username FROM users WHERE username = ? UNION SELECT username FROM admins WHERE username = ?");
            $stmt->bind_param('ss', $username, $username);
            $stmt->execute();
            $existingAccount = $stmt->get_result()->fetch_assoc();

            if ($existingAccount) {
                $error = 'That username is already in use.';
            } else {
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, 'user')");
                $stmt->bind_param('ss', $username, $hashedPassword);

                if ($stmt->execute()) {
                    session_regenerate_id(true);
                    $_SESSION['account_id'] = $conn->insert_id;
                    $_SESSION['username'] = $username;
                    $_SESSION['role'] = 'user';
                    $_SESSION['account_source'] = 'users';
                    header('Location: ../index.php');
                    exit;
                }

                $error = 'Registration could not be completed. Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Create Account | EswatiniHomes</title>
<style>
    :root{--primary:#0f5132;--primary-dark:#0a3622;--bg:#f6f7f5;--muted:#6b7280;}
    *{box-sizing:border-box;margin:0;padding:0;}
    body{font-family:'Segoe UI',Arial,sans-serif;background:var(--bg);display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px;}
    .register-box{background:#fff;padding:36px;border-radius:10px;box-shadow:0 6px 20px rgba(0,0,0,.1);width:100%;max-width:390px;}
    h1{color:var(--primary-dark);margin-bottom:6px;font-size:24px;}
    .sub{color:var(--muted);font-size:14px;margin-bottom:22px;}
    label{display:block;margin:14px 0 6px;font-weight:600;font-size:14px;color:#26332b;}
    input{width:100%;padding:11px 12px;border:1px solid #d7ddd8;border-radius:6px;font-size:15px;}
    input:focus{outline:2px solid #75a88c;outline-offset:1px;border-color:var(--primary);}
    button{width:100%;margin-top:22px;background:var(--primary);color:#fff;border:none;padding:12px;border-radius:6px;cursor:pointer;font-weight:600;font-size:15px;}
    button:hover{background:var(--primary-dark);}
    .error{background:#fdecea;color:#b00020;padding:10px 14px;border-radius:6px;font-size:13px;margin-bottom:10px;line-height:1.45;}
    .links{display:flex;justify-content:space-between;gap:12px;margin-top:18px;font-size:13px;}
    a{color:var(--primary);text-decoration:none;}
    a:hover{text-decoration:underline;}
</style>
</head>
<body>
    <main class="register-box">
        <h1>Create your account</h1>
        <p class="sub">Join EswatiniHomes to explore property listings.</p>

        <?php if ($error): ?><div class="error" role="alert"><?= htmlspecialchars($error) ?></div><?php endif; ?>

        <form method="POST" autocomplete="on">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">
            <label for="username">Username</label>
            <input id="username" type="text" name="username" minlength="3" maxlength="50" pattern="[A-Za-z0-9_]+" autocomplete="username" required value="<?= htmlspecialchars($username) ?>">

            <label for="password">Password</label>
            <input id="password" type="password" name="password" minlength="8" autocomplete="new-password" required>

            <label for="confirm_password">Confirm password</label>
            <input id="confirm_password" type="password" name="confirm_password" minlength="8" autocomplete="new-password" required>

            <button type="submit">Register</button>
        </form>
        <div class="links">
            <a href="login.php">Already registered? Sign in</a>
            <a href="../index.php">Back to listings</a>
        </div>
    </main>
</body>
</html>