<?php require_once __DIR__ . '/../include/config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? null)) {
        $error = 'Your session expired. Refresh the page and try again.';
    } else {
        $username = trim(request_string($_POST, 'username'));
        $password = request_string($_POST, 'password');

        $stmt = $conn->prepare("SELECT id, username, password, role FROM users WHERE username = ?");
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $account = $stmt->get_result()->fetch_assoc();

        if ($account && password_verify($password, $account['password'])) {
            session_regenerate_id(true);
            $_SESSION['account_id'] = $account['id'];
            $_SESSION['username'] = $account['username'];
            $_SESSION['role'] = $account['role'];
            $_SESSION['account_source'] = 'users';
            $destination = $account['role'] === 'admin'
                ? '../admin/dashboard.php'
                : ($account['role'] === 'agent' ? '../pages/agent-dashboard.php' : '../index.php');
            header('Location: ' . $destination);
            exit;
        }

        if (!$account) {
            $stmt = $conn->prepare("SELECT id, username, password FROM admins WHERE username = ?");
            $stmt->bind_param('s', $username);
            $stmt->execute();
            $admin = $stmt->get_result()->fetch_assoc();

            if ($admin && password_verify($password, $admin['password'])) {
                session_regenerate_id(true);
                $_SESSION['account_id'] = $admin['id'];
                $_SESSION['username'] = $admin['username'];
                $_SESSION['role'] = 'admin';
                $_SESSION['account_source'] = 'admins';
                header('Location: ../admin/dashboard.php');
                exit;
            }
        }

        $error = 'Invalid username or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign In | EswatiniHomes</title>
<link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
<style>
    :root{--primary:#0f5132;--primary-dark:#0a3622;--accent:#d4a017;--bg:#f6f7f5;}
    *{box-sizing:border-box;margin:0;padding:0;}
    body{font-family:'Segoe UI',Arial,sans-serif;background:var(--bg);display:flex;align-items:center;justify-content:center;min-height:100vh;}
    .login-box{background:#fff;padding:36px;border-radius:10px;box-shadow:0 6px 20px rgba(0,0,0,.1);width:100%;max-width:360px;}
    .login-box h1{color:var(--primary-dark);margin-bottom:6px;font-size:22px;}
    .login-box p.sub{color:#6b7280;font-size:13px;margin-bottom:20px;}
    label{display:block;margin:12px 0 6px;font-weight:600;font-size:14px;}
    input{width:100%;padding:10px 12px;border:1px solid #ddd;border-radius:6px;font-size:14px;}
    button{width:100%;margin-top:20px;background:var(--primary);color:#fff;border:none;padding:12px;border-radius:6px;cursor:pointer;font-weight:600;font-size:15px;}
    button:hover{background:var(--primary-dark);}
    .error{background:#fdecea;color:#b00020;padding:10px 14px;border-radius:6px;font-size:13px;margin-bottom:10px;}
    .back{display:block;text-align:center;margin-top:16px;font-size:13px;color:var(--primary);text-decoration:none;}
    .hint{margin-top:16px;font-size:12px;color:#9ca3af;text-align:center;}
</style>
</head>
<body>
    <div class="login-box">
        <h1>Sign In</h1>
        <p class="sub">Access your EswatiniHomes account</p>

        <?php if ($error): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrf_token()) ?>">
            <label>Username</label>
            <input type="text" name="username" required autofocus>

            <label>Password</label>
            <input type="password" name="password" required>

            <button type="submit">Log In</button>
        </form>
        <a class="back" href="register.php">Create a user account</a>
        <a class="back" href="../index.php"><i class="bx bx-chevron-left" aria-hidden="true"></i> Back to listings</a>
    </div>

<script>
    document.querySelector('form').addEventListener('submit', function(e){
        const u = this.username.value.trim();
        const p = this.password.value;
        if (!u || !p) {
            alert('Please fill in both fields.');
            e.preventDefault();
        }
    });
</script>
</body>
</html>
