<?php require_once __DIR__ . '/include/config.php';

// Build filters
$where = [];
$params = [];
$types = '';
$searchTerm = isset($_GET['q']) && is_string($_GET['q']) ? substr(trim($_GET['q']), 0, 100) : '';

if ($searchTerm !== '') {
    $where[] = "(title LIKE ? OR location LIKE ?)";
    $q = '%' . $searchTerm . '%';
    $params[] = $q; $params[] = $q;
    $types .= 'ss';
}
if (in_array($_GET['type'] ?? '', ['House', 'Apartment', 'Land', 'Commercial', 'Townhouse'], true)) {
    $where[] = "property_type = ?";
    $params[] = $_GET['type'];
    $types .= 's';
}
if (in_array($_GET['listing'] ?? '', ['Sale', 'Rent'], true)) {
    $where[] = "listing_type = ?";
    $params[] = $_GET['listing'];
    $types .= 's';
}
if (isset($_GET['max_price']) && is_numeric($_GET['max_price']) && (float)$_GET['max_price'] >= 0) {
    $where[] = "price <= ?";
    $params[] = (float)$_GET['max_price'];
    $types .= 'd';
}

$filterSql = $where ? ' AND ' . implode(' AND ', $where) : '';
$countStmt = $conn->prepare("SELECT COUNT(*) AS total FROM properties WHERE status = 'Approved'" . $filterSql);
if ($params) $countStmt->bind_param($types, ...$params);
$countStmt->execute();
$totalProperties = (int)$countStmt->get_result()->fetch_assoc()['total'];

$perPage = 12;
$totalPages = max(1, (int)ceil($totalProperties / $perPage));
$page = filter_var($_GET['page'] ?? 1, FILTER_VALIDATE_INT);
$page = $page === false || $page < 1 ? 1 : min($page, $totalPages);
$offset = ($page - 1) * $perPage;

$sql = "SELECT * FROM properties WHERE status = 'Approved'" . $filterSql;
$sql .= " ORDER BY featured DESC, created_at DESC";
$sql .= " LIMIT ? OFFSET ?";

$stmt = $conn->prepare($sql);
$queryParams = array_merge($params, [$perPage, $offset]);
$stmt->bind_param($types . 'ii', ...$queryParams);
$stmt->execute();
$result = $stmt->get_result();
$properties = $result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Eswatini Property Listings</title>
<link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
<style>
    :root{
        --primary:#0f5132;
        --primary-dark:#0a3622;
        --accent:#d4a017;
        --bg:#f6f7f5;
        --card-bg:#ffffff;
        --text:#222;
        --muted:#6b7280;
        --radius:10px;
    }
    *{box-sizing:border-box;margin:0;padding:0;}
    body{font-family:'Segoe UI',Arial,sans-serif;background:var(--bg);color:var(--text);}
    header{background:linear-gradient(135deg,var(--primary),var(--primary-dark));color:#fff;padding:18px 30px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;}
    header .logo{font-size:22px;font-weight:700;letter-spacing:.5px;}
    header .logo span{color:var(--accent);}
    nav a{color:#fff;text-decoration:none;margin-left:20px;font-size:15px;}
    nav a:hover{color:var(--accent);}
    .hero{background:url('assets/hero-house.png') center/cover;padding:70px 30px;text-align:center;color:#fff;position:relative;}
    .hero::before{content:'';position:absolute;inset:0;background:rgba(15,81,50,.55);}
    .hero h1,.hero p{position:relative;z-index:1;}
    .hero h1{font-size:34px;margin-bottom:10px;}
    .hero p{font-size:16px;opacity:.95;}

    .search-box{max-width:1000px;margin:-40px auto 30px;background:var(--card-bg);border-radius:var(--radius);box-shadow:0 8px 24px rgba(0,0,0,.12);padding:20px;position:relative;z-index:2;display:flex;flex-wrap:wrap;gap:12px;}
    .search-box input, .search-box select{flex:1;min-width:140px;padding:10px 12px;border:1px solid #ddd;border-radius:6px;font-size:14px;}
    .search-box button{background:var(--accent);color:#fff;border:none;padding:10px 22px;border-radius:6px;cursor:pointer;font-weight:600;}
    .search-box button:hover{opacity:.9;}

    .container{max-width:1200px;margin:0 auto;padding:0 24px 60px;}
    .section-title{font-size:22px;margin:20px 0;color:var(--primary-dark);}
    .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:22px;}
    .card{background:var(--card-bg);border-radius:var(--radius);overflow:hidden;box-shadow:0 3px 10px rgba(0,0,0,.08);transition:transform .2s, box-shadow .2s;}
    .card:hover{transform:translateY(-4px);box-shadow:0 10px 22px rgba(0,0,0,.14);}
    .card img, .card .placeholder{width:100%;height:190px;object-fit:cover;background:linear-gradient(135deg,#cfd9c7,#e5e9df);display:flex;align-items:center;justify-content:center;color:#8a9584;font-size:13px;}
    .card-body{padding:16px;}
    .badge{display:inline-block;font-size:11px;padding:3px 9px;border-radius:20px;background:var(--primary);color:#fff;margin-bottom:8px;}
    .badge.rent{background:var(--accent);}
    .card h3{font-size:17px;margin-bottom:6px;color:var(--text);}
    .card .price{font-size:18px;font-weight:700;color:var(--primary-dark);margin:6px 0;}
    .card .location{color:var(--muted);font-size:13px;margin-bottom:10px;}
    .meta{display:flex;gap:14px;font-size:13px;color:var(--muted);margin-bottom:12px;}
    .icon-text{display:inline-flex;align-items:center;gap:4px;}
    .icon-text i{font-size:16px;line-height:1;}
    .card a.view-btn{display:inline-block;background:var(--primary);color:#fff;text-decoration:none;padding:8px 16px;border-radius:6px;font-size:14px;}
    .card a.view-btn:hover{background:var(--primary-dark);}
    .empty{text-align:center;padding:60px 20px;color:var(--muted);}
    .pagination{display:flex;justify-content:center;align-items:center;gap:14px;margin-top:28px;color:var(--muted);font-size:14px;}
    .pagination a{color:var(--primary);font-weight:600;text-decoration:none;}
    footer{background:var(--primary-dark);color:#eee;text-align:center;padding:20px;font-size:13px;margin-top:40px;}
</style>
</head>
<body>

<header>
    <div class="logo">Eswatini<span>Homes</span></div>
    <nav>
        <a href="index.php">Home</a>
        <a href="pages/sale.php">For Sale</a>
        <a href="pages/rent.php">For Rent</a>
        <a href="pages/calculator.php">Payment Calculator</a>
        <a href="functions/add.php">List a Property</a>
        <?php if (is_logged_in()): ?>
            <a href="admin/dashboard.php">Admin Dashboard</a>
            <span>Admin: <?= htmlspecialchars($_SESSION['username']) ?></span>
            <a href="auth/logout.php">Logout</a>
        <?php elseif (($_SESSION['role'] ?? '') === 'agent'): ?>
            <a href="pages/agent-dashboard.php">Agent Dashboard</a>
            <span>Agent: <?= htmlspecialchars($_SESSION['username']) ?></span>
            <a href="auth/logout.php">Logout</a>
        <?php elseif (is_user_logged_in()): ?>
            <span><?= htmlspecialchars($_SESSION['username']) ?></span>
            <a href="auth/logout.php">Logout</a>
        <?php else: ?>
            <a href="auth/login.php">Sign In</a>
            <a href="auth/register.php">Register</a>
        <?php endif; ?>
    </nav>
</header>

<div class="hero">
    <h1>Find Your Perfect Property</h1>
    <p>Houses, apartments, land & commercial properties across Eswatini</p>
</div>

<form class="search-box" method="GET" action="index.php">
    <input type="text" name="q" placeholder="Search by title or location..." value="<?= htmlspecialchars($searchTerm) ?>">
    <select name="type">
        <option value="Any">Any Type</option>
        <?php foreach (['House','Apartment','Land','Commercial','Townhouse'] as $t): ?>
            <option value="<?= $t ?>" <?= (($_GET['type'] ?? '') === $t) ? 'selected' : '' ?>><?= $t ?></option>
        <?php endforeach; ?>
    </select>
    <select name="listing">
        <option value="Any">For Sale / Rent</option>
        <option value="Sale" <?= (($_GET['listing'] ?? '') === 'Sale') ? 'selected' : '' ?>>For Sale</option>
        <option value="Rent" <?= (($_GET['listing'] ?? '') === 'Rent') ? 'selected' : '' ?>>For Rent</option>
    </select>
    <input type="number" name="max_price" placeholder="Max Price (E)" value="<?= htmlspecialchars(is_scalar($_GET['max_price'] ?? '') ? (string)($_GET['max_price'] ?? '') : '') ?>">
    <button type="submit"><i class="bx bx-search" aria-hidden="true"></i> Search</button>
</form>

<div class="container">
    <h2 class="section-title"><?= $totalProperties ?> Properties Found</h2>

    <?php if (empty($properties)): ?>
        <div class="empty">No properties match your search. Try adjusting your filters.</div>
    <?php else: ?>
        <div class="grid">
            <?php foreach ($properties as $p): ?>
                <div class="card">
                    <?php if (property_image_exists($p['image'])): ?>
                        <img src="<?= htmlspecialchars(property_image_url($p['image'])) ?>" alt="<?= htmlspecialchars($p['title']) ?>">
                    <?php else: ?>
                        <div class="placeholder">No Image Available</div>
                    <?php endif; ?>
                    <div class="card-body">
                        <span class="badge <?= $p['listing_type'] === 'Rent' ? 'rent' : '' ?>">
                            <?= htmlspecialchars($p['listing_type'] === 'Rent' ? 'For Rent' : 'For Sale') ?> · <?= htmlspecialchars($p['property_type']) ?>
                        </span>
                        <h3><?= htmlspecialchars($p['title']) ?></h3>
                        <div class="location icon-text"><i class="bx bx-map-pin" aria-hidden="true"></i><?= htmlspecialchars($p['location']) ?></div>
                        <div class="price"><?= currency($p['price']) ?><?= $p['listing_type'] === 'Rent' ? ' /mo' : '' ?></div>
                        <div class="meta">
                            <span class="icon-text"><i class="bx bx-bed" aria-hidden="true"></i><?= (int)$p['bedrooms'] ?> Beds</span>
                            <span class="icon-text"><i class="bx bx-bath" aria-hidden="true"></i><?= (int)$p['bathrooms'] ?> Baths</span>
                            <span class="icon-text"><i class="bx bx-ruler" aria-hidden="true"></i><?= (float)$p['size_sqm'] ?> m²</span>
                        </div>
                        <a class="view-btn" href="functions/view.php?id=<?= $p['id'] ?>">View Details</a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <?php if ($totalPages > 1): ?>
        <?php $pageQuery = $_GET; ?>
        <nav class="pagination" aria-label="Listing pages">
            <?php if ($page > 1): $pageQuery['page'] = $page - 1; ?>
                <a href="?<?= htmlspecialchars(http_build_query($pageQuery)) ?>">Previous</a>
            <?php endif; ?>
            <span>Page <?= $page ?> of <?= $totalPages ?></span>
            <?php if ($page < $totalPages): $pageQuery['page'] = $page + 1; ?>
                <a href="?<?= htmlspecialchars(http_build_query($pageQuery)) ?>">Next</a>
            <?php endif; ?>
        </nav>
    <?php endif; ?>
</div>

<footer>&copy; <?= date('Y') ?> EswatiniHomes Property Listings. All rights reserved.</footer>

<script>
    // Simple client-side enhancement: highlight active filter selects
    document.querySelectorAll('.search-box select').forEach(function(sel){
        sel.addEventListener('change', function(){
            this.style.borderColor = '#0f5132';
        });
    });
</script>
</body>
</html>
