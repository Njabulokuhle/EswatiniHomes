<?php require_once __DIR__ . '/../include/config.php';
require_login();

$statuses = ['New', 'Contacted', 'Qualified', 'Closed'];
$propertyStatuses = ['Pending', 'Approved', 'Rejected'];
$error = '';
$notice = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? null)) {
        http_response_code(400);
        exit('Invalid request token. Refresh the page and try again.');
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'update_lead') {
        $leadId = (int)($_POST['lead_id'] ?? 0);
        $status = $_POST['status'] ?? '';

        if ($leadId < 1 || !in_array($status, $statuses, true)) {
            $error = 'Choose a valid lead status.';
        } else {
            $stmt = $conn->prepare("UPDATE leads SET status = ? WHERE id = ?");
            $stmt->bind_param('si', $status, $leadId);
            $stmt->execute();
            header('Location: dashboard.php?updated=lead');
            exit;
        }
    } elseif ($action === 'update_role') {
        $userId = (int)($_POST['user_id'] ?? 0);
        $role = $_POST['role'] ?? '';
        $isCurrentAccount = ($_SESSION['account_source'] ?? '') === 'users'
            && $userId === (int)($_SESSION['account_id'] ?? 0);

        if ($userId < 1 || !in_array($role, ['user', 'admin', 'agent'], true) || $isCurrentAccount) {
            $error = 'Choose a valid role for another registered account.';
        } else {
            $stmt = $conn->prepare("UPDATE users SET role = ? WHERE id = ?");
            $stmt->bind_param('si', $role, $userId);
            $stmt->execute();
            header('Location: dashboard.php?updated=role');
            exit;
        }
    } elseif ($action === 'update_property_status') {
        $propertyId = (int)($_POST['property_id'] ?? 0);
        $status = $_POST['status'] ?? '';

        if ($propertyId < 1 || !in_array($status, $propertyStatuses, true)) {
            $error = 'Choose a valid property status.';
        } else {
            $stmt = $conn->prepare('UPDATE properties SET status = ? WHERE id = ?');
            $stmt->bind_param('si', $status, $propertyId);
            $stmt->execute();
            header('Location: dashboard.php?updated=moderation');
            exit;
        }
    }
}

if (($_GET['updated'] ?? '') === 'lead') $notice = 'Lead status updated.';
if (($_GET['updated'] ?? '') === 'role') $notice = 'Account role updated.';
if (($_GET['updated'] ?? '') === 'property') $notice = 'Property deleted.';
if (($_GET['updated'] ?? '') === 'moderation') $notice = 'Listing status updated.';

$propertyCount = (int)$conn->query("SELECT COUNT(*) AS total FROM properties WHERE status = 'Approved'")->fetch_assoc()['total'];
$pendingPropertyCount = (int)$conn->query("SELECT COUNT(*) AS total FROM properties WHERE status = 'Pending'")->fetch_assoc()['total'];
$userCount = (int)$conn->query("SELECT COUNT(*) AS total FROM users WHERE role = 'user'")->fetch_assoc()['total'];
$adminCount = (int)$conn->query("SELECT COUNT(*) AS total FROM admins")->fetch_assoc()['total'];
$adminCount += (int)$conn->query("SELECT COUNT(*) AS total FROM users WHERE role = 'admin'")->fetch_assoc()['total'];
$newLeadCount = (int)$conn->query("SELECT COUNT(*) AS total FROM leads WHERE status = 'New'")->fetch_assoc()['total'];

$propertyPageSize = 12;
$propertyTotal = (int)$conn->query('SELECT COUNT(*) AS total FROM properties')->fetch_assoc()['total'];
$propertyPages = max(1, (int)ceil($propertyTotal / $propertyPageSize));
$propertyPage = filter_var($_GET['property_page'] ?? 1, FILTER_VALIDATE_INT);
$propertyPage = $propertyPage === false || $propertyPage < 1 ? 1 : min($propertyPage, $propertyPages);
$stmt = $conn->prepare('SELECT id, title, location, property_type, listing_type, price, status FROM properties ORDER BY created_at DESC LIMIT ? OFFSET ?');
$propertyOffset = ($propertyPage - 1) * $propertyPageSize;
$stmt->bind_param('ii', $propertyPageSize, $propertyOffset);
$stmt->execute();
$properties = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$leadPageSize = 25;
$leadTotal = (int)$conn->query('SELECT COUNT(*) AS total FROM leads')->fetch_assoc()['total'];
$leadPages = max(1, (int)ceil($leadTotal / $leadPageSize));
$leadPage = filter_var($_GET['lead_page'] ?? 1, FILTER_VALIDATE_INT);
$leadPage = $leadPage === false || $leadPage < 1 ? 1 : min($leadPage, $leadPages);
$stmt = $conn->prepare("SELECT leads.*, COALESCE(properties.title, leads.property_title) AS listing_title FROM leads LEFT JOIN properties ON properties.id = leads.property_id ORDER BY FIELD(leads.status, 'New', 'Contacted', 'Qualified', 'Closed'), leads.created_at DESC LIMIT ? OFFSET ?");
$leadOffset = ($leadPage - 1) * $leadPageSize;
$stmt->bind_param('ii', $leadPageSize, $leadOffset);
$stmt->execute();
$leads = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$accountPageSize = 25;
$accountTotal = (int)$conn->query('SELECT (SELECT COUNT(*) FROM users) + (SELECT COUNT(*) FROM admins) AS total')->fetch_assoc()['total'];
$accountPages = max(1, (int)ceil($accountTotal / $accountPageSize));
$accountPage = filter_var($_GET['account_page'] ?? 1, FILTER_VALIDATE_INT);
$accountPage = $accountPage === false || $accountPage < 1 ? 1 : min($accountPage, $accountPages);
$stmt = $conn->prepare("SELECT * FROM (SELECT id, username, role, created_at, 'users' AS source FROM users UNION ALL SELECT id, username, 'admin' AS role, NULL AS created_at, 'admins' AS source FROM admins) AS all_accounts ORDER BY created_at DESC, username ASC LIMIT ? OFFSET ?");
$accountOffset = ($accountPage - 1) * $accountPageSize;
$stmt->bind_param('ii', $accountPageSize, $accountOffset);
$stmt->execute();
$accounts = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$token = csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard | EswatiniHomes</title>
<style>
    :root{--green:#164b36;--green-dark:#103727;--gold:#d6a52b;--ink:#202a25;--muted:#68736c;--paper:#f3f5f1;--line:#dce2dc;--white:#fff;--red:#a33a32;}
    *{box-sizing:border-box;margin:0;padding:0;}
    body{font-family:'Segoe UI',Arial,sans-serif;background:var(--paper);color:var(--ink);}
    header{background:var(--green-dark);color:var(--white);padding:16px 28px;display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap;}
    .brand{font-weight:700;font-size:20px;}.brand span{color:var(--gold);}
    nav{display:flex;align-items:center;gap:18px;flex-wrap:wrap;}nav a{color:#fff;text-decoration:none;font-size:14px;}nav a:hover{color:var(--gold);}
    main{max-width:1320px;margin:0 auto;padding:32px 24px 60px;}
    .page-head{display:flex;align-items:flex-end;justify-content:space-between;gap:20px;flex-wrap:wrap;margin-bottom:24px;}
    h1{font-size:28px;color:var(--green-dark);margin-bottom:5px;}.page-head p{color:var(--muted);font-size:14px;}
    .primary-link{display:inline-block;background:var(--green);color:#fff;text-decoration:none;padding:10px 15px;border-radius:5px;font-weight:600;font-size:14px;}
    .metrics{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));border-block:1px solid var(--line);margin-bottom:28px;background:var(--white);}
    .metric{padding:17px 20px;border-right:1px solid var(--line);}.metric:last-child{border-right:0;}
    .metric span{display:block;color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.04em;}.metric strong{display:block;color:var(--green-dark);font-size:27px;margin-top:4px;}
    .notice{padding:12px 15px;background:#e3f1e7;color:#245a35;border-left:4px solid #438258;margin-bottom:18px;font-size:14px;}.notice.error{background:#f9e9e6;color:var(--red);border-color:var(--red);}
    .section{background:var(--white);border-top:3px solid var(--green);margin-top:24px;padding:20px 20px 8px;}
    .section-head{display:flex;justify-content:space-between;align-items:baseline;gap:12px;margin-bottom:14px;}.section h2{font-size:19px;color:var(--green-dark);}.section-head p{font-size:13px;color:var(--muted);}
    .table-wrap{overflow-x:auto;}table{width:100%;border-collapse:collapse;text-align:left;font-size:13px;min-width:680px;}th{font-size:11px;text-transform:uppercase;color:var(--muted);font-weight:700;letter-spacing:.04em;}th,td{padding:12px 10px;border-top:1px solid #e8ece8;vertical-align:middle;}td strong{font-size:14px;}td small{display:block;color:var(--muted);margin-top:3px;}
    .actions{display:flex;align-items:center;gap:10px;white-space:nowrap;}.actions a{color:var(--green);font-weight:600;text-decoration:none;}.actions a:hover{text-decoration:underline;}
    select,button{font:inherit;}select{padding:7px 8px;border:1px solid #cbd4cd;border-radius:4px;background:#fff;color:var(--ink);}button{border:0;border-radius:4px;padding:8px 10px;background:var(--green);color:#fff;font-weight:600;cursor:pointer;}button:hover{background:var(--green-dark);}button.danger{background:var(--red);}
    .role-form,.status-form{display:flex;align-items:center;gap:7px;}.role-tag{display:inline-block;padding:4px 8px;border-radius:3px;background:#e8eee9;color:var(--green-dark);font-size:12px;font-weight:600;}
    .pagination{display:flex;justify-content:center;align-items:center;gap:14px;padding:14px;color:var(--muted);font-size:13px;}
    .pagination a{color:var(--green);font-weight:600;text-decoration:none;}
    .lead-message{max-width:280px;white-space:normal;line-height:1.45;}.empty{padding:24px 10px!important;text-align:center;color:var(--muted);}
    @media(max-width:800px){main{padding:24px 15px 45px;}.metrics{grid-template-columns:repeat(2,minmax(0,1fr));}.metric:nth-child(2){border-right:0;}.metric:nth-child(-n+2){border-bottom:1px solid var(--line);}}
    @media(max-width:480px){header{padding:14px 16px;}nav{gap:12px;}h1{font-size:24px;}.section{padding:16px 12px 6px;}.metrics .metric{padding:14px;}}
</style>
</head>
<body>
<header>
    <div class="brand">Eswatini<span>Homes</span> / Admin</div>
    <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="../functions/add.php">Add listing</a>
        <a href="../index.php">View site</a>
        <a href="../auth/logout.php">Sign out</a>
    </nav>
</header>
<main>
    <div class="page-head">
        <div>
            <h1>Admin dashboard</h1>
            <p>Signed in as <?= htmlspecialchars($_SESSION['username'] ?? 'Admin') ?>. Review listings, accounts, and incoming enquiries.</p>
        </div>
        <a class="primary-link" href="../functions/add.php">Add a property</a>
    </div>

    <?php if ($notice): ?><div class="notice" role="status"><?= htmlspecialchars($notice) ?></div><?php endif; ?>
    <?php if ($error): ?><div class="notice error" role="alert"><?= htmlspecialchars($error) ?></div><?php endif; ?>

    <section class="metrics" aria-label="Site overview">
        <div class="metric"><span>Active listings</span><strong><?= $propertyCount ?></strong></div>
        <div class="metric"><span>Pending review</span><strong><?= $pendingPropertyCount ?></strong></div>
        <div class="metric"><span>Registered users</span><strong><?= $userCount ?></strong></div>
        <div class="metric"><span>Admin accounts</span><strong><?= $adminCount ?></strong></div>
        <div class="metric"><span>New leads</span><strong><?= $newLeadCount ?></strong></div>
    </section>

    <section class="section" id="leads">
        <div class="section-head"><h2>Property enquiries</h2><p><?= $leadTotal ?> total</p></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Contact</th><th>Property</th><th>Message</th><th>Received</th><th>Status</th><th>Update</th></tr></thead>
                <tbody>
                <?php if (!$leads): ?>
                    <tr><td class="empty" colspan="6">No enquiries have been received yet.</td></tr>
                <?php else: foreach ($leads as $lead): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($lead['name']) ?></strong><small><a href="mailto:<?= htmlspecialchars($lead['email']) ?>"><?= htmlspecialchars($lead['email']) ?></a></small><?php if ($lead['phone']): ?><small><?= htmlspecialchars($lead['phone']) ?></small><?php endif; ?></td>
                        <td><?= htmlspecialchars($lead['listing_title']) ?></td>
                        <td class="lead-message"><?= nl2br(htmlspecialchars($lead['message'])) ?></td>
                        <td><?= htmlspecialchars(date('M j, Y', strtotime($lead['created_at']))) ?></td>
                        <td><span class="role-tag"><?= htmlspecialchars($lead['status']) ?></span></td>
                        <td>
                            <form class="status-form" method="POST">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($token) ?>">
                                <input type="hidden" name="action" value="update_lead">
                                <input type="hidden" name="lead_id" value="<?= (int)$lead['id'] ?>">
                                <select name="status" aria-label="Status for lead from <?= htmlspecialchars($lead['name']) ?>">
                                    <?php foreach ($statuses as $status): ?><option value="<?= $status ?>" <?= $lead['status'] === $status ? 'selected' : '' ?>><?= $status ?></option><?php endforeach; ?>
                                </select>
                                <button type="submit">Save</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        <?php if ($leadPages > 1): ?>
            <?php $pageQuery = $_GET; ?>
            <nav class="pagination" aria-label="Enquiry pages">
                <?php if ($leadPage > 1): $pageQuery['lead_page'] = $leadPage - 1; ?><a href="?<?= htmlspecialchars(http_build_query($pageQuery)) ?>#leads">Previous</a><?php endif; ?>
                <span>Page <?= $leadPage ?> of <?= $leadPages ?></span>
                <?php if ($leadPage < $leadPages): $pageQuery['lead_page'] = $leadPage + 1; ?><a href="?<?= htmlspecialchars(http_build_query($pageQuery)) ?>#leads">Next</a><?php endif; ?>
            </nav>
        <?php endif; ?>
    </section>

    <section class="section" id="listings">
        <div class="section-head"><h2>Listings</h2><p><?= $propertyTotal ?> total</p></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Property</th><th>Type</th><th>Listing</th><th>Status</th><th>Price</th><th>Actions</th></tr></thead>
                <tbody>
                <?php if (!$properties): ?>
                    <tr><td class="empty" colspan="6">No properties found.</td></tr>
                <?php else: foreach ($properties as $property): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($property['title']) ?></strong><small><?= htmlspecialchars($property['location']) ?></small></td>
                        <td><?= htmlspecialchars($property['property_type']) ?></td>
                        <td><?= htmlspecialchars($property['listing_type']) ?></td>
                        <td>
                            <form class="status-form" method="POST">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($token) ?>">
                                <input type="hidden" name="action" value="update_property_status">
                                <input type="hidden" name="property_id" value="<?= (int)$property['id'] ?>">
                                <select name="status" aria-label="Status for <?= htmlspecialchars($property['title']) ?>">
                                    <?php foreach ($propertyStatuses as $status): ?><option value="<?= $status ?>" <?= $property['status'] === $status ? 'selected' : '' ?>><?= $status ?></option><?php endforeach; ?>
                                </select>
                                <button type="submit">Save</button>
                            </form>
                        </td>
                        <td><?= htmlspecialchars(currency($property['price'])) ?></td>
                        <td class="actions">
                            <a href="../functions/view.php?id=<?= (int)$property['id'] ?>">View</a>
                            <a href="../functions/edit.php?id=<?= (int)$property['id'] ?>">Edit</a>
                            <form method="POST" action="../functions/delete.php" onsubmit="return confirm('Delete this property?');">
                                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($token) ?>">
                                <input type="hidden" name="id" value="<?= (int)$property['id'] ?>">
                                <button class="danger" type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        <?php if ($propertyPages > 1): ?>
            <?php $pageQuery = $_GET; ?>
            <nav class="pagination" aria-label="Property pages">
                <?php if ($propertyPage > 1): $pageQuery['property_page'] = $propertyPage - 1; ?><a href="?<?= htmlspecialchars(http_build_query($pageQuery)) ?>#listings">Previous</a><?php endif; ?>
                <span>Page <?= $propertyPage ?> of <?= $propertyPages ?></span>
                <?php if ($propertyPage < $propertyPages): $pageQuery['property_page'] = $propertyPage + 1; ?><a href="?<?= htmlspecialchars(http_build_query($pageQuery)) ?>#listings">Next</a><?php endif; ?>
            </nav>
        <?php endif; ?>
    </section>

    <section class="section" id="accounts">
        <div class="section-head"><h2>Accounts and roles</h2><p><?= $accountTotal ?> total</p></div>
        <div class="table-wrap">
            <table>
                <thead><tr><th>Username</th><th>Role</th><th>Created</th><th>Change role</th></tr></thead>
                <tbody>
                <?php if (!$accounts): ?>
                    <tr><td class="empty" colspan="4">No registered accounts found.</td></tr>
                <?php else: foreach ($accounts as $account): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($account['username']) ?></strong></td>
                        <td><span class="role-tag"><?= htmlspecialchars(ucfirst($account['role'])) ?></span></td>
                        <td><?= $account['created_at'] ? htmlspecialchars(date('M j, Y', strtotime($account['created_at']))) : 'Legacy admin' ?></td>
                        <td>
                            <?php if ($account['source'] === 'users' && !(($_SESSION['account_source'] ?? '') === 'users' && (int)$account['id'] === (int)($_SESSION['account_id'] ?? 0))): ?>
                                <form class="role-form" method="POST">
                                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($token) ?>">
                                    <input type="hidden" name="action" value="update_role">
                                    <input type="hidden" name="user_id" value="<?= (int)$account['id'] ?>">
                                    <select name="role" aria-label="Role for <?= htmlspecialchars($account['username']) ?>">
                                        <option value="user" <?= $account['role'] === 'user' ? 'selected' : '' ?>>User</option>
                                        <option value="admin" <?= $account['role'] === 'admin' ? 'selected' : '' ?>>Admin</option>
                                        <option value="agent" <?= $account['role'] === 'agent' ? 'selected' : '' ?>>Agent</option>
                                    </select>
                                    <button type="submit">Save</button>
                                </form>
                            <?php elseif ($account['source'] === 'users'): ?>
                                <span class="role-tag">Your account</span>
                            <?php else: ?>
                                <span class="role-tag">Managed in database</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        <?php if ($accountPages > 1): ?>
            <?php $pageQuery = $_GET; ?>
            <nav class="pagination" aria-label="Account pages">
                <?php if ($accountPage > 1): $pageQuery['account_page'] = $accountPage - 1; ?><a href="?<?= htmlspecialchars(http_build_query($pageQuery)) ?>#accounts">Previous</a><?php endif; ?>
                <span>Page <?= $accountPage ?> of <?= $accountPages ?></span>
                <?php if ($accountPage < $accountPages): $pageQuery['account_page'] = $accountPage + 1; ?><a href="?<?= htmlspecialchars(http_build_query($pageQuery)) ?>#accounts">Next</a><?php endif; ?>
            </nav>
        <?php endif; ?>
    </section>
</main>
</body>
</html>